# Input data

## Distributed input

`data/planning_inputs.npz` contains the processed arrays used by the two cases. The original dtypes and array values are retained. The horizontal CRS is EPSG:4547, the spacing is 5 m, and the grid has 1156 × 1150 × 30 nodes. The x axis increases eastward, the y axis decreases with array index, and z contains absolute elevation coordinates from 0 to 145 m at 5 m spacing.

| Key | Shape | Meaning / unit |
|---|---|---|
| `x`, `y`, `z` | 1D coordinate vectors | projected horizontal coordinates and elevation, m |
| `valid` | 1156 × 1150 | study/data coverage mask |
| `dem` | 1156 × 1150 | terrain elevation, m |
| `pop` | 1156 × 1150 | interpolated source population value, persons per original 100 m source cell |
| `pop_norm` | 1156 × 1150 | logarithmically normalized population proxy |
| `rain` | 1156 × 1150 | June 2024 monthly accumulated precipitation, mm |
| `bheight`, `bmask` | 1156 × 1150 | relative building height (m) and footprint mask |
| `nearest_ix`, `nearest_iy` | 1156 × 1150 | indices of the nearest rasterized building cell |
| `droad`, `dbld`, `dwater` | 1156 × 1150 | horizontal distance to the relevant rasterized feature, m |
| `nfz` | 1156 × 1150 | rasterized hard geofence including the 200 m buffer |

The inputs contain no three-dimensional fused cost array. `src/run.py` constructs the six fields and hard mask from these arrays. This avoids distributing a redundant 219 MB NetCDF field.

## Source processing

Terrain and population rasters were bilinearly resampled into the planning grid. The local terrain file is named `GEBCO-DEM.tif`; its recorded coordinate spacing is 1/240 degree. The population source is `PopSE_China2020_100m.tif` (2020, 100 m). Bilinear population interpolation yields a continuous source-cell population proxy, not population counts for individual 5 m cells. The density-equivalent conversion used in the results is source population × 100 persons/km².

Precipitation comes from the TPDC 1-km monthly precipitation dataset for China, cited as Peng (2020), DOI: https://doi.org/10.5281/zenodo.3114194. Dataset page: https://www.tpdc.ac.cn/zh-hans/data/faae7605-a0f2-4d18-b28f-5cee413766a2/. The local file `pre_2024.nc` contains 12 monthly layers on a 1/120-degree grid. June was selected, values in 0.1 mm were converted to mm, and the layer was bilinearly resampled. Resampling does not increase the source information resolution. The processed study-area precipitation spans approximately 285.26–297.64 mm/month.

Building footprints and their `Height` attribute were rasterized with all-touched coverage, sorted by increasing height so that taller buildings determine overlapping cells. `Height` is relative to the ground. Modeled roof elevation equals DEM plus this height. The nearest building cell and its roof are used in the proximity field. The source elevation datum and source-specific height uncertainty are not independently calibrated by this workflow.

Roads and water bodies were rasterized before Euclidean distance transforms. The supplied hard-geofence mask uses the 200 m buffer polygons with all-touched rasterization. The study coverage mask is stored explicitly; terrain, population and precipitation had no missing values inside it. Missing or out-of-domain cells must not be interpreted as zero planning cost.

Original raw files are not needed for runs from these processed inputs and are not included. Source-product citations and data-use conditions continue to apply to the derived inputs; no new open-data license is asserted for third-party products.

## Endpoints

`config/od_pairs.json` contains only OD01 (Pair 1) and OD02 (Pair 2). Coordinates are grid indices in x/y/z order. These are the original horizontal endpoints with the lowest traversable elevation at each endpoint under the nominal hard constraints. All model comparisons preserve these endpoints. Coarse-grid performance runs report offsets and add explicit connectors to the common fine-grid endpoints.
