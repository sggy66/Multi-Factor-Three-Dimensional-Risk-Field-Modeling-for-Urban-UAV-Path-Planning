# Verification

## Executed checks

The distributed implementation passed 32 small-graph algorithm checks, including constant-field integrals, axis and diagonal steps, A* versus Dijkstra, independently recomputed objectives, blocked corner transitions, unreachable paths, out-of-grid contacts and pure vertical segments.

The 48 exported core comparison paths were independently reevaluated using the distributed processed inputs. Checks cover coordinates and common endpoints, full-segment nominal and own-field hard constraints, factor and population integrals, length, peak/mean cost, terrain/building clearance, AGL and raw optimized objective decomposition. `results/reference/verification.json` records the checks and maximum differences. This report concerns the core paths, not a fresh rerun of every parameter experiment.

Both nominal full-model routes were also replanned and reconstructed from the new package. Raw node arrays and reconstructed node arrays were exactly equal to the corresponding reference arrays; all compared scientific metrics matched exactly. The new full-workflow timings are in `results/tables/full_workflow.csv`.

The 18 archived resolution/corridor records were copied without changing their numeric values. The original performance script did not save path NPZs. For those archived records, the verification code checks the recorded timing and metric relationships and explicitly records that exported path files are absent; it does not claim a new segment trace. Re-running the performance stage saves these path files for independent checking.

## Repeat verification

From the repository root:

```bash
python scripts/verify_package.py
python src/run.py --stage verify --output results/reference --table core
python src/run.py --stage verify --output runs
```

The first command checks every distributed file against SHA-256. The second reevaluates the supplied core paths without replanning. The third validates available newly generated outputs. Reports go to `runs/verification.json`; `--report` can select another report path. Use `--table` to select specific result tables; omitting it checks all available tables. Joint and height-error verification rebuilds the applicable planning fields and can take longer than the nominal check.

Small floating-point tolerances are used for recomputed metrics. Failures and geometry differences in perturbed scenarios must remain visible; nominal and perturbed hard masks have different meanings. These checks establish computational consistency within the model and do not validate operational accident risk or vehicle dynamics.
