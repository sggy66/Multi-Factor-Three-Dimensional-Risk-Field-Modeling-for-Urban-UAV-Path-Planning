# Package validation

The release was checked on 8 November 2026 with Python 3.10. The processed
inputs and the original search, field, surface and evaluation kernels are
unchanged. Tests used a separate copy of the package in a directory containing
spaces, with outputs and compilation caches outside the distributed files.

## Recorded full-experiment verification

The archived independent reports cover all 480 paired-parameter paths, all
96 interior-height-error replans and all 96 fixed-path checks. They are in
`results/followup/analysis/verification_joint.json` and
`results/followup/analysis/verification_height.json`. Six-pair nominal path
verification is in `results/six_od/independent_path_verification.json`.

## Relocated-package checks

- Replanned Pair 3 with both models. Recorded scientific metrics and the
  discrete, reconstructed and coordinate path arrays matched the nominal
  reference results exactly.
- Replanned setting J00 on all six pairs with both models: 12 runs. All path
  arrays and scientific metrics matched the archived setting. Independent
  verification of these new paths passed.
- Independently checked the archived +10 m building-height interior-error
  case: 12 replanned paths and 12 fixed nominal paths. Endpoint feasibility,
  constraints, clearance and common-field evaluation checks passed.
- Regenerated all nine follow-up CSV summaries. They matched the archived
  summaries byte for byte.
- Regenerated the six-pair nominal comparison and scene summaries. Ninety
  reported numeric or scene values matched the separately archived metric,
  factor-integral and scene-description tables.

These release checks confirm representative execution and portable input/output
handling. The full 480-run and 96-replan suites were not rerun during relocation;
their original full verification reports remain included. Runtime measurements
are machine dependent.

The distribution also passes Python syntax checks, source-manifest verification
and the complete file SHA-256 check. To check the received files, run
`python scripts/verify_package.py` from the repository root.
