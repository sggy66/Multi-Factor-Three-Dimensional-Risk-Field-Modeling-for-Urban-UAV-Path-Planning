# Computational performance

## Environment and measurement scope

The reference experiments used an AMD Ryzen 7 4800H processor (8 physical cores, 16 logical CPUs) and approximately 16 GB installed memory (15.372 GiB available to the operating system). The recorded platform is Windows build 26200, with Python 3.10.6, NumPy 1.25.0, SciPy 1.15.3, Numba 0.63.1 and psutil 7.1.3. The Numba search kernels are single threaded. Full software versions are provided in `results/reference/environment.json`.

These measurements concern the two original OD pairs: OD01 is Pair 1 and OD02 is Pair 2. Each search uses a rectangle enclosing its endpoints, expanded by the stated horizontal margin and clipped to the planning-grid extent.

The supplied processed spatial inputs reconstruct the six cost fields and the independent hard-constraint mask. Field construction starts after these arrays are loaded; it does not include original product acquisition, raster reprojection or vector preprocessing. The reference performance batch required 5.279855 s for nominal field construction and 0.672254 s for cache loading and small-graph checks.

## Search time, explored nodes and memory

Wall-clock time is measured with `time.perf_counter`. Each resolution/margin combination has three consecutive search calls. `initial_call_s` records the first call, which may include signature compilation or cache loading; `warmed_repeat_s` records the next two calls. `median_s` is the median of those two warmed calls. The timed search includes projected lower-bound heuristic construction, queue expansion and discrete path extraction.

An explored node is counted once when it is removed from the priority queue and closed, including the goal. Duplicate queue entries are excluded. Counts do not include nodes processed separately to construct the projected heuristic.

Process resident set size (RSS) is sampled every 20 ms with psutil. `peak_rss_mib` is the largest sampled process RSS over all three calls, expressed in MiB (2^20 bytes). It includes the interpreter, imported libraries, inputs and resident factor arrays. It is not an estimate of incremental search allocation, and brief peaks between samples may be missed. The original fine-grid arrays remain resident during coarse searches, so the reported memory does not describe an isolated coarse-grid implementation.

A separate fresh-cache measurement took 11.021049 s to compile and execute search and evaluation on a 6 x 6 x 4 graph. This is a compilation experiment rather than a full-grid route time; its five subsequent small-graph measurements appear in `results/reference/compilation_timing.json`.

## Grid resolution and corridor tests

The 5 m graph is the nominal graph. The 10 m and 20 m graphs are conservative aggregates: a coarse cell is blocked if any fine child is blocked, and its soft cost is the mean of its children. Coarse endpoints are selected in their corresponding columns and can be displaced from the nominal endpoints. Explicit connectors join the coarse route to the original fine-grid endpoints. All connectors and route segments are evaluated against the fine hard mask, and path quality is evaluated in the same fixed nominal full-model field.

These resolutions therefore use different state graphs. Their optimized objectives are not interchangeable, even though the final length, nominal mean cost and nominal integral use common endpoint and evaluation definitions. The reference tests use discrete paths without trajectory reconstruction.

### Reference performance table

All 18 settings found paths with feasible common-endpoint connectors and zero recorded hard intersections. Values below are rounded for display; `results/tables/performance.csv` retains the recorded values, initial-call times, repeat times, node counts and endpoint offsets. Length is in metres, mean cost is dimensionless, and the cost integral is in metres.

| Pair | Grid m | Margin m | Warm median s | Peak RSS MiB | Length m | Mean cost | Cost integral m |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 5 | 800 | 3.932763 | 1413.719 | 8271.9081 | 0.2184119 | 1806.6834 |
| 1 | 5 | 1200 | 3.922608 | 1413.809 | 8271.9081 | 0.2184119 | 1806.6834 |
| 1 | 5 | 1600 | 4.021840 | 1413.820 | 8271.9081 | 0.2184119 | 1806.6834 |
| 1 | 10 | 800 | 0.318693 | 1437.559 | 8298.8527 | 0.2199726 | 1825.5199 |
| 1 | 10 | 1200 | 0.312617 | 1437.559 | 8298.8527 | 0.2199726 | 1825.5199 |
| 1 | 10 | 1600 | 0.324809 | 1437.559 | 8298.8527 | 0.2199726 | 1825.5199 |
| 1 | 20 | 800 | 0.027900 | 1418.043 | 8350.2161 | 0.2212189 | 1847.2260 |
| 1 | 20 | 1200 | 0.028067 | 1418.043 | 8350.2161 | 0.2212189 | 1847.2260 |
| 1 | 20 | 1600 | 0.028099 | 1418.043 | 8350.2161 | 0.2212189 | 1847.2260 |
| 2 | 5 | 800 | 3.139252 | 1413.820 | 5771.5992 | 0.2614366 | 1508.9071 |
| 2 | 5 | 1200 | 2.806110 | 1413.758 | 5771.5992 | 0.2614366 | 1508.9071 |
| 2 | 5 | 1600 | 2.792643 | 1413.766 | 5771.5992 | 0.2614366 | 1508.9071 |
| 2 | 10 | 800 | 0.244464 | 1437.559 | 5778.7390 | 0.2623581 | 1516.0989 |
| 2 | 10 | 1200 | 0.249307 | 1437.559 | 5778.7390 | 0.2623581 | 1516.0989 |
| 2 | 10 | 1600 | 0.264091 | 1437.562 | 5778.7390 | 0.2623581 | 1516.0989 |
| 2 | 20 | 800 | 0.021228 | 1418.043 | 5750.8483 | 0.2676339 | 1539.1222 |
| 2 | 20 | 1200 | 0.023253 | 1418.043 | 5750.8483 | 0.2676339 | 1539.1222 |
| 2 | 20 | 1600 | 0.025787 | 1418.043 | 5750.8483 | 0.2676339 | 1539.1222 |

The complete reference performance batch took 82.529391 s and peaked at 1454.890625 MiB sampled process RSS. This batch includes input loading, field construction, cache loading and checks, 18 configurations with three search calls each, coarsening, fine-field evaluation and output. It does not include trajectory reconstruction. These batch quantities, stored in `results/reference/performance_batch_timing.json`, are not per-route workflow measurements.

## Reference reconstruction timings

The nominal full-model reference runs separately recorded search and reconstruction measurements:

| Pair | Search s | Optimizer and candidate validation s | Remaining postprocessing s | Search peak RSS MiB |
|---|---:|---:|---:|---:|
| 1 | 9.970864 | 0.109186 | 0.020463 | 1558.699 |
| 2 | 2.919828 | 0.096881 | 0.015788 | 1559.262 |

The original reconstruction timer starts immediately before L-BFGS-B and includes optimization and candidate validation. Earlier bound setup is included in the remaining postprocessing timer. Initial raw-path evaluation occurs before these postprocessing timers. The search timer also includes sampler setup and shutdown. Consequently, these reference columns do not sum to a measured complete workflow time. Search RSS is sampled during search only and excludes later reconstruction and evaluation allocations. Both reference full-model reconstructions passed acceptance checks at the optimizer iteration limit; acceptance does not imply convergence.

## Algorithmic scaling

For a bounded search graph with V states and a fixed 26-neighbour degree, the heap-based graph search has a worst-case time bound of O(V log V) and O(V) search storage. The projected heuristic also scans the bounded volume and solves a two-dimensional lower-bound graph. Whole-grid field construction and resident field storage scale with the total grid size N. These algorithmic bounds describe growth with problem size; they are separate from the measured wall-clock times and process RSS above. Iterative reconstruction cost also depends on path-node count and the number of optimization and validation iterations.

## Full-workflow measurements from the distributed implementation

The supplied implementation was run in two separate processes, one full-model case per process. Both reproduced the raw and reconstructed node arrays exactly, and the checked scientific metrics matched the recorded reference results. The code measures complete function scopes for reconstruction and evaluation, including segment-wise surface and population metrics.

`complete_workflow_s` starts at main() entry after Python module imports and includes processed-input loading, field construction, kernel checks, exact-signature warmup, route calculation, independent objective/constraint checks, record and path output. It excludes source-product preprocessing and interpreter/import startup. The final runtime-JSON write and memory-monitor shutdown occur after this timer. Process RSS is sampled across this workflow.

The route-only total excludes the shared load/build/warmup stages. Warmup may compile or load an uncached function signature; the first process took longer than the second. Warmup measurements are recorded explicitly and must not be compared as if both started from an empty compiler cache. These are single-run whole-workflow checks, not estimates of a mean runtime.

| Pair | Input load s | Field build s | Checks/cache s | Signature warmup s | Search s | Reconstruction s | Evaluation s | Route-only s | Complete workflow s | Peak RSS MiB |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 0.196453 | 5.052724 | 0.599256 | 7.562853 | 4.045894 | 0.121938 | 0.869009 | 6.010069 | 19.486721 | 2802.707031 |
| 2 | 0.200475 | 5.166794 | 0.555287 | 0.059540 | 2.683819 | 0.105725 | 0.573013 | 3.853555 | 9.899349 | 2803.597656 |

Full-precision values and remaining verification/output time are in `results/tables/full_workflow.csv` and `results/reference/full_workflow_timing.json`. Search time includes memory-monitor setup and join. Reconstruction time covers the entire reconstruction function; evaluation time covers both raw and final metrics and metric enrichment. Remaining route time includes export, monitor overhead and memory cleanup.
