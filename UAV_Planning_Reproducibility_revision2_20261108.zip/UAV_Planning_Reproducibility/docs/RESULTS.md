# Result definitions

CSV files under `results/reference/` contain only OD01 and OD02. Valid paths are stored in NPZ files under `results/reference/paths/`, with `raw_index` for discrete search nodes, `index` for the final exported polyline and `xyz` for projected coordinates. Failed cases remain in the CSV; missing metrics are not zeros.

| File | Cases |
|---|---:|
| `core.csv` | 48 |
| `ratio.csv` | 30 |
| `joint.csv` | 80 |
| `height_error.csv` | 16 |
| `fixed_path_error.csv` | 16 |
| `rain_threshold.csv` | 2 |
| `performance.csv` | 18 |

`route_profiles.csv` supplies profile data for the main comparison paths. Its repeated rows are profile samples, not independent OD cases.

## Metrics

- `objective_discrete`: the objective minimized by the original discrete A* search, in that configuration's own field.
- `movement_discrete`: horizontal movement plus 2.5 times absolute vertical movement.
- `risk_term_discrete`: rho times the own-field path integral. Together with movement it reconstructs the objective.
- `objective_independent`: independently recomputed discrete objective.
- `length_m`: exported three-dimensional polyline length, m.
- `risk_integral`, `mean_risk`, `peak_risk`: integral (m), length-weighted mean (dimensionless) and peak (dimensionless) in the fixed nominal full-model field. The historical variable names do not denote accident probabilities.
- `pop/alt/road/bld/wth/riv_integral`: unweighted factor integrals; multiplication by the nominal weights reconstructs the nominal full-field integral.
- `population_native_mean/integral`: population exposure before logarithmic scaling, in the original source-cell value scale. Density-equivalent fields multiply this value by 100 to obtain persons/km² (or persons·m/km² for the integral).
- `avg_agl_m`: line-length-weighted altitude above the nominal terrain, including departure and arrival segments.
- `min_segment_nominal_surface_clearance_m`: minimum vertical clearance above the nominal terrain-plus-building surface over all exported segments and boundary contacts.
- `hard_intersections`: hard-mask contacts under the configuration used for planning; `nominal_hard_intersections`: contacts under the fixed nominal mask. These can differ in perturbed-height experiments. Contact counts are not counts of distinct obstacles.
- `nodes`: distinct nodes closed by A*, including the goal; repeated heap entries are not counted again.
- `smooth_status`, `repair_attempts`: reconstruction acceptance and attempted blending candidates. Acceptance at the optimizer iteration limit is not a claim of numerical convergence.
- `raw_*`: metrics before reconstruction. Cross-objective `raw_objective_*` values evaluate the same discrete path under specified alternative fields; they are not the objective minimized by every configuration.

Joint, ratio, height-perturbation and threshold experiments retain discrete paths without reconstruction. Core comparisons use constraint-checked reconstruction. Do not compare an own-field optimized objective directly with a score defined in a different field.

## Table summaries

`python scripts/summarize_results.py` generates compact core-control, ablation, factor-addition, reconstruction joint-sensitivity and risk–distance scan tables from the CSV values. The supplied files in `results/tables/` use the recorded reference results. These summaries do not silently replace failed outcomes or average across different objective definitions.

The scan summary reports discrete-path mean planning cost in the fixed nominal full-model field and untransformed population means relative to the full model at the same coefficient and OD pair. A population ratio below one means lower native population exposure than that matching full-model path. The denominator changes with coefficient; the ratios must not be treated as absolute population values or used to compare absolute exposure across coefficients. Raw native population values, lengths and cost integrals remain in `results/reference/ratio.csv`.

`height_bias_feasibility.csv` reports fixed-path feasibility and replanning status for eight separately applied height-bias scenarios on the two pairs. The fixed paths are the nominal reconstructed full-model paths. Replanning keeps absolute endpoint indices unchanged. Failed rows are classified as blocked endpoints only after checking the endpoint occupancy predicates against the supplied inputs; this does not establish that no route exists if departure/arrival elevations are reset. In these scenarios, all six failed replanning cases have blocked endpoints. Full constraint-contact counts and metrics of successful replans remain in the reference CSVs.

`discrete_objectives.csv` reports all 23 A* configurations on both original pairs (46 paths), before reconstruction. Movement is horizontal length plus 2.5 times absolute vertical movement; the soft term is 12 times the integral in each configuration's own field. Both terms and the total objective have units of metres under the dimensionless planning coefficients. Objectives from different cost fields must not be ranked directly. The prescribed 60 m AGL control is excluded because it was not obtained by optimizing this objective. The total is rounded from its full-precision value, not calculated from rounded display components.


`cross_objectives.csv` evaluates each of the original full-model and two population-only discrete paths under all three cost fields. The movement term is unchanged and rho is 12; only the integrated soft field varies. Compare rows within the same OD pair and objective column. The full-model path has the lowest full-field objective among these three paths, while each population-only path has the lowest objective under its matching population coefficient. This is a comparison of the revised arc-length objective with simplified population cost fields, not a reproduction of the published Primatesta method. Values are independently rounded to one decimal place.


`factor_contributions.csv` records the six weighted contributions for all 48 final core trajectories, using the fixed nominal full-model weights for evaluation regardless of the field used to plan each route. Each value is the nominal weight multiplied by the corresponding factor integral along the final trajectory. Their sum reconstructs the nominal full-field integral, with less than 0.001 m difference from float32 fusion. These are exposure-proxy or preference-cost contributions, not casualty probabilities and not the configuration's own optimized objective.

`factor_contributions_summary.csv` contains the 24 final trajectories from the main controls, individual factor additions and intermediate cumulative additions (12 configurations on each of the two pairs), rounded independently to one decimal place. The prescribed AGL control is included as an evaluated final trajectory rather than an optimized discrete path. Individually adding each of road, building, precipitation or water reduced its corresponding factor integral in both pairs relative to population plus altitude, but the full-field integral was not improved by every addition.

## Six-pair and matched extensions

The scope above describes the original results/reference directory. The expanded nominal and paired comparisons are stored separately under results/six_od and results/followup; see EXTENDED_EXPERIMENTS.md for counts, conventions and commands.
