# Extended model comparisons

## Design

The six pairs are all unordered combinations of the four original endpoint
states, with fixed archived directions. Pairs 1 and 2 retain their detailed
baseline and ablation analyses. All six pairs compare the full model with
population plus altitude under identical hard constraints.

Both objectives use horizontal movement plus 2.5 times absolute vertical
movement and 12 times the integral of their own planning-cost field. Nominal
full weights are (0.35, 0.15, 0.15, 0.15, 0.10, 0.10). The simpler model keeps
the first two weights and sets the other four to zero without renormalization.
All common metrics use the fixed nominal full-model field. Nominal comparisons
use accepted reconstructed trajectories; parameter and height-error replans
are evaluated without reconstruction.

## Paired parameters

The unchanged 40 settings in `config/joint_parameters.json` are applied to both
models on each pair: 480 runs and 240 paired comparisons. Shared parameters and
retained weights match. Positive benefit is 100*(I_simple-I_full)/I_simple.
Ranking uses tolerance max(1e-4, 1e-6*max(abs(I_full), abs(I_simple))). Counts
describe these prespecified stress tests. Full-model integrals are lower in
213 comparisons; the simpler model is lower in 27. Medians and P10/P90 are
reported separately for each pair. Weighted factor integrals use nominal
weights during evaluation.

## Interior height errors

The same horizontal spatial multiplier is used for both models: zero within
100 m of any of the four endpoints, a raised-cosine transition from 100 to
200 m, and one beyond 200 m. Terrain and relative building heights are shifted
separately by -10, -5, +5 and +10 m. Relative building heights are clipped at
zero and changed only inside footprints. A terrain shift also changes roof
elevation and AGL-dependent constraints and costs. Endpoints remain fixed.

There are 96 replanning cases and 96 fixed nominal reconstructed-path checks.
All are feasible in the recorded tests, with no constraint violations. Minimum
interior clearance is 8.461 m for fixed paths and 3.981 m for replans; the
minimum whole-route clearance is 2.781 m for both groups. The protected endpoint
neighborhoods are a controlled design for separating endpoint and interior
sensitivity, not a claim about the spatial distribution of real data errors.

The derived spatial multiplier is recreated from the grid and endpoint
configuration; a duplicate 8 MB array archive is unnecessary. The original
global-shift tests, including all six endpoint-blocked failures, are retained.

## Records and portability

The search, field, reconstruction and evaluation implementations are unchanged.
The main entry point accepts six endpoint configurations while retaining the
original two as its default selection. Follow-up scripts have relative input
paths, writable run directories and separate verification reports. Source
hashes in `config/followup_sources.json` bind these scripts, inputs and nominal
reference paths. `checksums.sha256` covers the complete distributed inventory.

Verification may be limited with `--sample` or `--case`; its reports state the
actual number checked. Full archived independent verification reports are
included under `results/followup/analysis/`. Timing depends on the machine and
compilation state. Scientific metrics are compared with floating-point
tolerances. No runtime directory, review correspondence or manuscript is part
of this package.
