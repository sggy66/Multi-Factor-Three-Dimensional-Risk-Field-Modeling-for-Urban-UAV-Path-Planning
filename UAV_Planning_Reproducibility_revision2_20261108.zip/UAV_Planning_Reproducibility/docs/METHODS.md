# Methods and algorithmic workflow

## 1. Field construction

The grid is a piecewise-constant spatial field. Array indices identify voxel centres; boundaries occur at half-integer indices. Coordinates are converted to metres using the 5 m spacing. Soft fields and the Boolean hard mask are constructed independently.

Let P be the interpolated source population, h = z − DEM, d_r / d_b / d_w horizontal distance to the rasterized roads / buildings / water, and H_b the roof elevation of the nearest rasterized building cell. The nominal parameters are stored in `config/experiment.json`.

1. Population: R_pop = log(1 + max(P, 0)) / log(1 + P_max), with P_max determined over valid study cells. The supplied `pop_norm` retains the exact processed values.
2. Altitude: clip h to [0, H_max] for soft evaluation; R_alt = 1 − (1 − r_min)(h/H_opt)^alpha ((H_max − h)/(H_max − H_opt))^beta, where beta = alpha(H_max − H_opt)/H_opt. Nominal H_opt = 60 m, H_max = 120 m, alpha = 2, r_min = 0.2. Terrain and ceiling restrictions remain in the separate mask.
3. Road: R_road = 0.6 exp(−d_r²/(2 sigma_r²)) exp(−lambda max(h, 0)); nominal sigma_r = 15 m, lambda = 0.02 m⁻¹.
4. Building: R_bld = omega exp(−d_b²/(2 sigma_b²)) exp(−max(z − H_b, 0)²/(2 sigma_b²)); nominal omega = 0.7, sigma_b = 15 m. H_b uses DEM plus relative building height at the nearest building cell. Building solids are independently forbidden.
5. Precipitation: R_rain = 1 − exp(−(rain/eta)^gamma), with eta = 350 mm/month and gamma = 3. Monthly accumulation is a static background proxy. The optional 500 mm/month hard threshold is off in nominal experiments and is only a hypothetical scenario.
6. Water: R_water = 1 − exp(−d_w²/(2 sigma_w²)), with sigma_w = 30 m. The value is zero on rasterized water, without overriding hard constraints.

Fusion has two stages: first form R = Σ w_i R_i with weights (0.35, 0.15, 0.15, 0.15, 0.10, 0.10); then apply the independent Boolean hard mask. No finite soft value makes a forbidden voxel traversable. Invalid coverage, buffered geofences, terrain, building solids and cells exceeding the AGL ceiling are blocked. For 5 m cells, terrain/building intersection uses z − 2.5 m and ceiling intersection uses z + 2.5 m. The weights encode planning preferences rather than calibrated physical risk contributions.

## 2. Objective, neighbours and heuristic

For a candidate edge u→v, the movement term is horizontal length plus 2.5 times absolute vertical displacement. The soft term is rho times the exact piecewise-constant three-dimensional line integral. The nominal rho is 12:

J(path) = Σ_edges [horizontal_length + 2.5 |vertical_displacement|] + rho ∫_path R ds.

For an adjacent voxel-centre edge, half of its length lies in each endpoint voxel, so the soft integral equals edge length × (R(u) + R(v))/2. Axis, face-diagonal and body-diagonal lengths are therefore handled consistently.

Search uses 26 neighbours inside the endpoints' horizontal bounding rectangle expanded by an 800 m margin and clipped to the study grid. The vertical extent is the available grid. A candidate edge is rejected if any touched closed cell is forbidden, including ties at faces, edges and corners.

The consistent heuristic combines two lower bounds: (a) direct horizontal distance, vertical movement and minimum feasible soft cost; (b) a goal-centred projected 2D Dijkstra potential using the minimum feasible cost in each vertical column, plus vertical movement. The larger bound is used. The projected graph deliberately omits some 3D restrictions and is optimistic. A node is counted once when removed from the heap and closed. Duplicate heap entries are excluded. Search ends when the goal is closed or the queue is empty.

## 3. Reconstruction and full-segment evaluation

The raw horizontal node coordinates are retained. Elevations are optimized using L-BFGS-B, minimizing summed squared second elevation differences plus 0.001 times summed squared displacement from the raw elevations. Bounds retain each node in its connected free vertical interval and within ±5 m of its original elevation; endpoints are fixed. The solver uses maxiter = 300, ftol = 1e−10 and gtol = 1e−6.

Candidate blends with the raw elevations use fractions 1, 1/2, 1/4, 1/8 and 1/16. Accept the first candidate with zero hard contacts, no more than 1% increases in length or nominal planning-cost integral, and at least 50% reduction in elevation roughness unless raw RMS roughness is below 0.05 m. If none passes, retain the valid raw path. Fewer than four nodes remain unchanged. Acceptance is a geometric and metric check; an optimizer iteration-limit status does not imply numerical convergence.

Exported trajectories are polylines. Every segment is split at voxel boundaries for length-weighted integration. All boundary contacts are checked separately for feasibility, including face-following and pure vertical segments. Minimum vertical clearance above DEM plus building height and AGL statistics are evaluated along the segments rather than only at vertices. This does not validate vehicle dynamics or real flight safety.

## 4. Experimental configurations

All comparisons use the original OD01/OD02 endpoints and the same hard constraints.

- Full, uniform, population-only (coefficient 1 and 0.35), population plus altitude.
- Six deletions with retained weights fixed; six with retained weights renormalized.
- From population plus altitude, individually add road, building, rain or water; cumulative order is road, building, rain, water.
- A 60 m AGL cruise follows the uniform path's horizontal projection with explicit departure/arrival segments; it is not locally raised to bypass violations.
- Risk–distance scan: rho = 3, 6, 12, 24, 48 for full and both population-only scales.
- Joint stress test: the 40 frozen settings in `config/joint_parameters.json`, each applied to both pairs. Weights and response scales are perturbed jointly, rho is 3–48, and reference AGL is 40/60/80 m. These are exploratory ranges, not physical calibration intervals.
- Terrain and relative-building offsets: −10, −5, +5, +10 m. Both fixed nominal paths in perturbed masks and replanning in perturbed fields are reported. These are assumed scenarios, not measured source-error distributions.
- Monthly precipitation threshold: 500 mm/month on. The study-area June values are below this threshold; a no-change result is retained.
- Grid/corridor test: resolutions 5/10/20 m and margins 800/1200/1600 m. Coarse soft values are child-cell means, coarse hard masks block any cell with a blocked fine child. Edge strips are truncated to dimensions divisible by the aggregation factor. Fine-grid common endpoints are connected to the coarse solution and independently validated; state graphs and coarse objectives differ.

All quality scores use the fixed nominal full-model field. The own-field objective is separately recomputed and decomposed. Parameter experiments retain discrete paths without reconstruction. Success within two cases is not a claim of generalizability across routes or regions.

## 5. Pseudocode

```text
INPUT: processed spatial arrays, two OD pairs, parameters and configuration list
OUTPUT: case records, valid discrete/final paths, quality and resource metrics

ConstructFields(inputs, parameters):
    compute six continuous channels on the valid grid
    fuse channels using configuration weights
    construct hard mask from coverage, terrain, roofs, ceiling and geofences
    return channels, fused cost, hard mask

IntegrateAndCheck(path, fields, hard_mask):
    for each nonzero segment:
        split at every voxel-boundary crossing
        integrate field value × actual 3D length in each interval
        check all touched cells at crossings and face/edge-following intervals
    return length, movement, integrals, peaks and hard-contact count

BoundedAStar(cost, hard_mask, start, goal, margin):
    bound horizontal search rectangle; retain available vertical layers
    reject blocked endpoints
    construct projected lower-bound potential
    initialise g(start)=0, heap and closed set
    while heap is nonempty:
        pop node; skip if already closed; close and count it
        if node is goal: return backtracked discrete path and objective
        for each of 26 neighbours inside bounds:
            reject any transition touching a forbidden closed cell
            compute movement plus rho × 3D soft integral
            relax g and push with the consistent heuristic
    return failure with no fabricated metrics

Reconstruct(raw_path):
    retain horizontal coordinates and fixed endpoints
    bound elevations by connected free intervals and ±5 m
    optimize elevation roughness with the finite solver settings
    test five blend fractions using IntegrateAndCheck
    accept first passing candidate, otherwise retain the raw path

RunCase(configuration, OD):
    construct own field/mask and search
    retain failure record if search fails
    independently recompute raw optimized objective and its terms
    reconstruct only when requested for core comparisons
    evaluate all exported segments in the fixed nominal field/mask
    compute factor/population/AGL/clearance metrics
    write case record and valid path

RunExperiments:
    load frozen nominal inputs, two ODs and joint settings
    construct fixed nominal fields and hard mask
    run declared baseline, deletion and addition configurations
    run parameter/height/threshold scenarios without reconstruction
    run conservative grid/corridor comparisons
    preserve failures, own/nominal differences and measurement scopes
```
