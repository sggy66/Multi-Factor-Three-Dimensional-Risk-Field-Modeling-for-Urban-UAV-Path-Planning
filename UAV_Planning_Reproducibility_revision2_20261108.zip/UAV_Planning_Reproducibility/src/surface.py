"""Complete line integrals of AGL and vertical modeled-surface clearance."""
import numpy as np
from numba import njit
from kernel import segment_cells

@njit(cache=True)
def surface_stats(p,dem,surface):
 minimum=1e100;terrain_min=1e100;agl_integral=0.;aglmax=-1e100;total=0.
 for k in range(len(p)-1):
  a=p[k];b=p[k+1];dv=b-a;L=np.sqrt(np.sum(dv*dv))*5
  if L<1e-12:continue
  total+=L;ts=segment_cells(a,b)
  for j in range(len(ts)-1):
   if ts[j+1]-ts[j]<1e-12:continue
   mid=a+.5*(ts[j+1]+ts[j])*dv;ix=int(np.floor(mid[0]+.5));iy=int(np.floor(mid[1]+.5))
   zlo=min(a[2]+ts[j]*dv[2],a[2]+ts[j+1]*dv[2])*5;zhi=max(a[2]+ts[j]*dv[2],a[2]+ts[j+1]*dv[2])*5
   minimum=min(minimum,zlo-surface[ix,iy]);terrain_min=min(terrain_min,zlo-dem[ix,iy]);aglmax=max(aglmax,zhi-dem[ix,iy]);agl_integral+=(ts[j+1]-ts[j])*L*(mid[2]*5-dem[ix,iy])
  # Surface discontinuities at contacts: check both sides, including face-following segments.
  for j in range(2*len(ts)-1):
   t=ts[j//2] if j%2==0 else .5*(ts[j//2]+ts[j//2+1]);m=a+t*dv
   ix=int(np.floor(m[0]+.5));iy=int(np.floor(m[1]+.5))
   for xx in range(ix-1 if abs(m[0]+.5-round(m[0]+.5))<1e-8 else ix,ix+1):
    for yy in range(iy-1 if abs(m[1]+.5-round(m[1]+.5))<1e-8 else iy,iy+1):
     if xx>=0 and yy>=0 and xx<dem.shape[0] and yy<dem.shape[1]:
      minimum=min(minimum,m[2]*5-surface[xx,yy]);terrain_min=min(terrain_min,m[2]*5-dem[xx,yy])
 return minimum,terrain_min,agl_integral/total,aglmax
