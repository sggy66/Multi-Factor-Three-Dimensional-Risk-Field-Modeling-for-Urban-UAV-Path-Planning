"""Exact piecewise-constant line integrals and conservative 26-neighbour A*."""
import heapq, math
import numpy as np
from numba import njit

@njit(cache=True)
def potential_2d(cost,hard,xmin,xmax,ymin,ymax,gx,gy,resolution,rho):
 """Optimistic projected costs: minimize each column over all feasible heights."""
 bx=xmax-xmin+1;by=ymax-ymin+1;nz=cost.shape[2]
 low=np.full((bx,by),math.inf)
 for a in range(bx):
  for b in range(by):
   for c in range(nz):
    if not hard[a+xmin,b+ymin,c]:low[a,b]=min(low[a,b],np.float64(cost[a+xmin,b+ymin,c]))
 dist=np.full((bx,by),math.inf);closed=np.zeros((bx,by),np.uint8)
 gx-=xmin;gy-=ymin;dist[gx,gy]=0.;heap=[(0.,gx*by+gy)]
 while heap:
  value,idx=heapq.heappop(heap);a=idx//by;b=idx%by
  if closed[a,b]:continue
  closed[a,b]=1
  for da in range(-1,2):
   for db in range(-1,2):
    if da==0 and db==0:continue
    aa=a+da;bb=b+db
    if aa<0 or aa>=bx or bb<0 or bb>=by or closed[aa,bb]:continue
    if not np.isfinite(low[aa,bb]):continue
    ds=resolution*math.sqrt(da*da+db*db)
    cand=value+ds*(1.+rho*.5*(low[a,b]+low[aa,bb]))
    if cand<dist[aa,bb]:dist[aa,bb]=cand;heapq.heappush(heap,(cand,aa*by+bb))
 return dist

@njit(cache=True)
def search(cost, hard, start, goal, resolution=5., rho=12., vert=2.5, margin=160, use_heuristic=True):
 nx,ny,nz=cost.shape
 xmin=max(0,min(start[0],goal[0])-margin);xmax=min(nx-1,max(start[0],goal[0])+margin)
 ymin=max(0,min(start[1],goal[1])-margin);ymax=min(ny-1,max(start[1],goal[1])+margin)
 bx=xmax-xmin+1;by=ymax-ymin+1;plane=by*nz;size=bx*plane
 empty=np.empty((0,3),np.int32)
 if hard[start[0],start[1],start[2]] or hard[goal[0],goal[1],goal[2]]:return empty,math.inf,0
 dirs=np.empty((26,3),np.int32);move=np.empty(26);length=np.empty(26)
 checks=np.zeros((26,8,3),np.int32);counts=np.zeros(26,np.int32);q=0
 for di in range(-1,2):
  for dj in range(-1,2):
   for dk in range(-1,2):
    if di==0 and dj==0 and dk==0:continue
    dirs[q]=np.array([di,dj,dk]);move[q]=resolution*(math.sqrt(di*di+dj*dj)+vert*abs(dk));length[q]=resolution*math.sqrt(di*di+dj*dj+dk*dk)
    for a in range(2 if di!=0 else 1):
     for b in range(2 if dj!=0 else 1):
      for c in range(2 if dk!=0 else 1):
       checks[q,counts[q]]=np.array([di*a,dj*b,dk*c]);counts[q]+=1
    q+=1
 minimum=math.inf
 for ia in range(xmin,xmax+1):
  for ib in range(ymin,ymax+1):
   for ic in range(nz):
    if not hard[ia,ib,ic]:minimum=min(minimum,float(cost[ia,ib,ic]))
 projected=potential_2d(cost,hard,xmin,xmax,ymin,ymax,goal[0],goal[1],resolution,rho) if use_heuristic else np.zeros((bx,by))
 sid=((start[0]-xmin)*by+start[1]-ymin)*nz+start[2]
 gid=((goal[0]-xmin)*by+goal[1]-ymin)*nz+goal[2]
 g=np.full(size,math.inf);parent=np.full(size,-1,np.int8);closed=np.zeros(size,np.uint8)
 g[sid]=0.;heap=[(0.,sid)];nodes=0
 while heap:
  _,cur=heapq.heappop(heap)
  if closed[cur]:continue
  closed[cur]=1;nodes+=1
  if cur==gid:
   out=[];ptr=cur
   while True:
    a=ptr//plane;b=(ptr%plane)//nz;c=ptr%nz;out.append((a+xmin,b+ymin,c))
    if ptr==sid:break
    m=parent[ptr]
    if m<0:return empty,math.inf,nodes
    ptr=((a-dirs[m,0])*by+b-dirs[m,1])*nz+c-dirs[m,2]
   path=np.empty((len(out),3),np.int32)
   for i in range(len(out)):
    path[i,0]=out[len(out)-1-i][0];path[i,1]=out[len(out)-1-i][1];path[i,2]=out[len(out)-1-i][2]
   return path,g[cur],nodes
  a=cur//plane+xmin;b=(cur%plane)//nz+ymin;c=cur%nz
  for m in range(26):
   aa=a+dirs[m,0];bb=b+dirs[m,1];cc=c+dirs[m,2]
   if aa<xmin or aa>xmax or bb<ymin or bb>ymax or cc<0 or cc>=nz:continue
   idx=((aa-xmin)*by+bb-ymin)*nz+cc
   if closed[idx]:continue
   collision=False
   for k in range(counts[m]):
    if hard[a+checks[m,k,0],b+checks[m,k,1],c+checks[m,k,2]]:collision=True;break
   if collision:continue
   cand=g[cur]+move[m]+rho*length[m]*.5*(np.float64(cost[a,b,c])+np.float64(cost[aa,bb,cc]))
   if cand+1e-10<g[idx]:
    g[idx]=cand;parent[idx]=m
    dx=(aa-goal[0])*resolution;dy=(bb-goal[1])*resolution;dz=(cc-goal[2])*resolution
    h=max(math.sqrt(dx*dx+dy*dy)+vert*abs(dz)+rho*minimum*math.sqrt(dx*dx+dy*dy+dz*dz),projected[aa-xmin,bb-ymin]+vert*abs(dz)) if use_heuristic else 0.
    heapq.heappush(heap,(cand+h,idx))
 return empty,math.inf,nodes

@njit(cache=True)
def segment_cells(a,b):
 """Cell index coordinates, node centres at integers, boundaries at n+1/2."""
 ts=[0.,1.]
 for ax in range(3):
  d=b[ax]-a[ax]
  if abs(d)<1e-12:continue
  lo=min(a[ax],b[ax]);hi=max(a[ax],b[ax])
  for n in range(math.floor(lo-.5)+1,math.floor(hi-.5)+1):
   t=(n+.5-a[ax])/d
   if 1e-12<t<1.-1e-12:ts.append(t)
 tt=np.array(ts);tt.sort();return tt

@njit(cache=True)
def path_metrics(p,fields,hard,resolution=5.):
 """Integrate fields over every cell interval; check all cells at boundary ties."""
 nf=fields.shape[0];sums=np.zeros(nf);peak=np.zeros(nf);hits=0;total=0.;effort=0.
 nx,ny,nz=hard.shape
 for i in range(len(p)-1):
  a=p[i];b=p[i+1];delta=b-a;length=math.sqrt(np.sum(delta*delta))*resolution
  if length<1e-12:continue
  total+=length;effort+=(math.sqrt(delta[0]**2+delta[1]**2)+2.5*abs(delta[2]))*resolution
  ts=segment_cells(a,b)
  for j in range(len(ts)-1):
   if ts[j+1]-ts[j]<1e-12:continue
   m=a+.5*(ts[j]+ts[j+1])*delta
   x=math.floor(m[0]+.5);y=math.floor(m[1]+.5);z=math.floor(m[2]+.5)
   if x<0 or x>=nx or y<0 or y>=ny or z<0 or z>=nz:hits+=1;continue
   if hard[x,y,z]:hits+=1
   for k in range(nf):
    v=fields[k,x,y,z];sums[k]+=(ts[j+1]-ts[j])*length*v;peak[k]=max(peak[k],v)
  # Midpoints of intervals also capture segments lying along a cell face.
  for j in range(len(ts)*2-1):
   t=ts[j//2] if j%2==0 else .5*(ts[j//2]+ts[j//2+1])
   m=a+t*delta;choices=np.zeros((3,2),np.int32);count=np.ones(3,np.int32)
   for ax in range(3):
    v=m[ax]+.5;fl=math.floor(v);choices[ax,0]=fl
    if abs(v-round(v))<1e-8:choices[ax,1]=fl-1;count[ax]=2
   for xi in range(count[0]):
    for yi in range(count[1]):
     for zi in range(count[2]):
      x=choices[0,xi];y=choices[1,yi];z=choices[2,zi]
      if x<0 or x>=nx or y<0 or y>=ny or z<0 or z>=nz:hits+=1
      elif hard[x,y,z]:hits+=1
 return total,effort,sums,peak,hits

def run_tests():
 results=[]
 def check(name,ok,detail=''):
  if not ok:raise AssertionError(name+': '+detail)
  results.append(dict(test=name,passed=True,detail=detail))
 c=np.full((5,5,5),.3,'f4');h=np.zeros(c.shape,bool);f=c[None]
 for goal in [(4,2,2),(4,4,2),(4,4,4)]:
  start=(2,2,2);p,j,n=search(c,h,np.array(start),np.array(goal),margin=10)
  L,M,I,P,H=path_metrics(p.astype(float),f,h)
  check('constant_'+str(goal),abs(I[0]-.3*L)<2e-6 and abs(j-M-12*I[0])<1e-5)
 rng=np.random.default_rng(20260930)
 for i in range(12):
  c=rng.uniform(0,1,(6,6,4)).astype('f4');h=rng.random(c.shape)<.15;h[0,0,1]=False;h[-1,-1,2]=False
  pa,ja,na=search(c,h,np.array([0,0,1]),np.array([5,5,2]),margin=20)
  pd,jd,nd=search(c,h,np.array([0,0,1]),np.array([5,5,2]),margin=20,use_heuristic=False)
  check('astar_dijkstra_'+str(i),(np.isinf(ja) and np.isinf(jd)) or abs(ja-jd)<1e-7)
  if len(pa):
   L,M,I,P,H=path_metrics(pa.astype(float),c[None],h)
   check('independent_J_'+str(i),abs(ja-(M+12*I[0]))<1e-6 and H==0)
 c=np.zeros((2,2,2),'f4');h=np.zeros(c.shape,bool);h[1,0,0]=True
 p,j,n=search(c,h,np.array([0,0,0]),np.array([1,1,1]),margin=2)
 if len(p):check('corner_safety',path_metrics(p.astype(float),c[None],h)[-1]==0)
 check('direct_corner_blocked',path_metrics(np.array([[0.,0.,0.],[1.,1.,1.]]),c[None],h)[-1]>0)
 h[:]=True;h[0,0,0]=False
 check('unreachable',len(search(c,h,np.array([0,0,0]),np.array([1,1,1]))[0])==0)
 h[:]=False;p=np.array([[0.,0.,0.],[0.,0.,1.]])
 check('pure_vertical',abs(path_metrics(p,c[None],h)[0]-5)<1e-9)
 p=np.array([[0.,0.,0.],[2.,0.,0.]])
 check('out_of_grid',path_metrics(p,c[None],h)[-1]>0)
 return results
