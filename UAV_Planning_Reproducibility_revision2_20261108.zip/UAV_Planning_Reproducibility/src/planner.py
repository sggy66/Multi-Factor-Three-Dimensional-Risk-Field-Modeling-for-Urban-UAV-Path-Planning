"""Planning fields, bounded search, reconstruction, and trajectory evaluation."""
from pathlib import Path
import csv, json, time, threading, gc
import numpy as np
from scipy.optimize import minimize
import psutil
from kernel import search, path_metrics
from surface import surface_stats

KEYS = ['pop', 'alt', 'road', 'bld', 'wth', 'riv']
W = np.array([.35, .15, .15, .15, .1, .1])
RHO = 12.
PARAM = dict(hopt=60., hmax=120., alpha=2., rmin=.2, road_sigma=15., road_lambda=.02,
             bld_sigma=15., bld_omega=.7, water_sigma=30., rain_eta=350., rain_beta=3.,
             rain_hard=False, terrain_shift=0., building_shift=0.)
OUT = Path('runs')

def fields(d,p=PARAM):
 """Recompute six channels; missing cells and modeled constraints use a separate mask."""
 nx,ny,nz=len(d['x']),len(d['y']),len(d['z']);res=d['x'][1]-d['x'][0]
 ff=np.empty((6,nx,ny,nz),'f4');hard=np.empty((nx,ny,nz),bool)
 dem=d['dem']+p['terrain_shift'];height=np.maximum(d['bheight']+p['building_shift'],0);roof=dem+height
 nr=roof[d['nearest_ix'],d['nearest_iy']]
 beta=p['alpha']*(p['hmax']-p['hopt'])/p['hopt']
 wa=1-np.exp(-(d['rain']/p['rain_eta'])**p['rain_beta'])
 ri=1-np.exp(-d['dwater']**2/(2*p['water_sigma']**2))
 rh=p['rain_hard']&(d['rain']>=500)
 for iz,z in enumerate(d['z']):
  h=z-dem;hc=np.clip(h,0,p['hmax'])
  alt=1-(1-p['rmin'])*(hc/p['hopt'])**p['alpha']*((p['hmax']-hc)/(p['hmax']-p['hopt']))**beta
  rd=.6*np.exp(-d['droad']**2/(2*p['road_sigma']**2))*np.exp(-p['road_lambda']*np.maximum(h,0))
  bld=p['bld_omega']*np.exp(-d['dbld']**2/(2*p['bld_sigma']**2))*np.exp(-np.maximum(z-nr,0)**2/(2*p['bld_sigma']**2))
  for k,v in enumerate([d['pop_norm'],alt,rd,bld,wa,ri]):ff[k,:,:,iz]=np.where(d['valid'],v,0)
  # Occupied cells intersect closed terrain/building solids or exceed the ceiling.
  hard[:,:,iz]=~d['valid']|d['nfz']|(z-res/2<=dem)|(z+res/2>dem+p['hmax'])|(d['bmask']&(z-res/2<=roof))|rh
 if not np.all(np.isfinite(ff)):raise ValueError('non-finite planning field')
 return ff,hard

def fused(ff,w):
 out=np.zeros(ff.shape[1:],'f4')
 for i in range(6):out+=w[i]*ff[i]
 return out

class PeakMemory:
 def __enter__(self):
  self.stop=False;self.p=psutil.Process();self.peak=self.p.memory_info().rss
  def worker():
   while not self.stop:self.peak=max(self.peak,self.p.memory_info().rss);time.sleep(.02)
  self.t=threading.Thread(target=worker,daemon=True);self.t.start();return self
 def __exit__(self,*args):self.stop=True;self.t.join();self.peak=max(self.peak,self.p.memory_info().rss)

def evaluation_stack(d,nom,nomcost,own):
 f=np.empty((9,*own.shape),'f4');f[:6]=nom;f[6]=nomcost;f[7]=own
 for k in range(own.shape[2]):f[8,:,:,k]=d['pop']
 return f

def smooth(p,hard,evalfields):
 """Bounded elevation roughness minimization; horizontal geometry is retained."""
 if len(p)<4:return p,'unchanged short path',0,0.
 z=p[:,2]*5;ix=p[:,0].astype(int);iy=p[:,1].astype(int);lo=z-5;hi=z+5
 for k in range(len(p)):
  safe=np.flatnonzero(~hard[ix[k],iy[k]])
  # Retain the connected vertical run containing the raw node.
  q=int(p[k,2]);a=q;b=q
  while a>0 and not hard[ix[k],iy[k],a-1]:a-=1
  while b+1<hard.shape[2] and not hard[ix[k],iy[k],b+1]:b+=1
  lo[k]=max(lo[k],a*5);hi[k]=min(hi[k],b*5)
 lo[0]=hi[0]=z[0];lo[-1]=hi[-1]=z[-1]
 def fun(v):
  dd=v[:-2]-2*v[1:-1]+v[2:];dz=v-z
  grad=.002*dz;grad[:-2]+=2*dd;grad[1:-1]-=4*dd;grad[2:]+=2*dd
  return float(np.sum(dd**2)+.001*np.sum(dz**2)),grad
 started=time.perf_counter();fit=minimize(fun,z,jac=True,method='L-BFGS-B',bounds=list(zip(lo,hi)),options=dict(maxiter=300,ftol=1e-10,gtol=1e-6))
 base=path_metrics(p.astype(float),evalfields,hard);baseR=base[2][6]
 rawrough=float(np.sqrt(np.mean(np.diff(z,n=2)**2)))
 for k,alpha in enumerate([1,.5,.25,.125,.0625]):
  candidate=p.astype(float).copy();candidate[:,2]=(z+alpha*(fit.x-z))/5
  mm=path_metrics(candidate,evalfields,hard);rough=float(np.sqrt(np.mean(np.diff(candidate[:,2]*5,n=2)**2)))
  if mm[-1]==0 and mm[0]<=base[0]*1.01+1e-6 and mm[2][6]<=baseR*1.01+1e-6 and (rawrough<.05 or rough<=rawrough*.5):
   return candidate,'accepted' if fit.success else 'accepted at iteration limit',k,time.perf_counter()-started
 return p.astype(float),'fallback to valid discrete path',5,time.perf_counter()-started

def coords(d,p):return np.column_stack([d['x'][0]+p[:,0]*5,d['y'][0]-p[:,1]*5,p[:,2]*5])

def record(table,row):
 path=OUT/(table+'.jsonl')
 with open(path,'a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n')
 rows=[json.loads(s) for s in path.read_text(encoding='utf-8').splitlines()];keys=list(dict.fromkeys(k for r in rows for k in r))
 with open(OUT/(table+'.csv'),'w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows([{k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()} for r in rows])

def done(table):
 p=OUT/(table+'.jsonl');return {(r['od'],r['variant']) for r in map(json.loads,p.read_text(encoding='utf-8').splitlines())} if p.exists() else set()

def solve(d,nom,nomcost,hard,od,variant,w=W,rho=RHO,ownff=None,ownhard=None,table='core',smoothing=True,margin=160):
 if (od['id'],variant) in done(table):return
 cost=fused(nom if ownff is None else ownff,w);hh=hard if ownhard is None else ownhard
 start=np.array(od['start']);goal=np.array(od['goal']);started=time.perf_counter()
 with PeakMemory() as pm:p,J,n=search(cost,hh,start,goal,5.,rho,2.5,margin)
 search_s=time.perf_counter()-started
 row=dict(od=od['id'],variant=variant,found=bool(len(p)),rho=float(rho),weights=w.tolist(),search_s=search_s,nodes=int(n),peak_rss_mib=pm.peak/2**20,margin_m=margin*5,algorithm_version='projected_consistent_astar_v2')
 if not len(p):row['failure_reason']='blocked endpoints or no path in bounded search';record(table,row);print(table,od['id'],variant,'NO PATH',flush=True);return
 evaluation_started=time.perf_counter();ef=evaluation_stack(d,nom,nomcost,cost);raw=path_metrics(p.astype(float),ef,hh)
 rawJ=raw[1]+rho*raw[2][7]
 if abs(rawJ-J)>max(1e-5,abs(J)*1e-7):raise AssertionError('objective reconstruction mismatch '+str((rawJ,J)))
 evaluation_before_s=time.perf_counter()-evaluation_started
 reconstruction_started=time.perf_counter();pp,status,rep,optimizer_s=smooth(p,hh,ef) if smoothing else (p.astype(float),'not reconstructed for parameter/performance analysis',0,0.)
 smooth_s=time.perf_counter()-reconstruction_started if smoothing else 0.
 evaluation_started=time.perf_counter()
 met=path_metrics(pp,ef,hh);nominal_hits=path_metrics(pp,ef,hard)[-1] if ownhard is not None else met[-1]
 xyz=coords(d,pp);ii=np.clip(np.floor(pp[:,0]+.5).astype(int),0,len(d['x'])-1);jj=np.clip(np.floor(pp[:,1]+.5).astype(int),0,len(d['y'])-1)
 agl=xyz[:,2]-d['dem'][ii,jj];sur=d['dem'][ii,jj]+d['bheight'][ii,jj]
 row.update(objective_discrete=float(J),movement_discrete=float(raw[1]),risk_term_discrete=float(rho*raw[2][7]),objective_independent=float(rawJ),length_m=float(met[0]),risk_integral=float(met[2][6]),mean_risk=float(met[2][6]/met[0]),peak_risk=float(met[3][6]),population_native_integral=float(met[2][8]),population_native_mean=float(met[2][8]/met[0]),own_risk_integral=float(met[2][7]),avg_agl_m=float(np.average((agl[:-1]+agl[1:])/2,weights=np.linalg.norm(np.diff(xyz,axis=0),axis=1))),max_agl_m=float(np.max(agl)),min_vertex_surface_clearance_m=float(np.min(xyz[:,2]-sur)),hard_intersections=int(met[-1]),nominal_hard_intersections=int(nominal_hits),raw_length_m=float(raw[0]),raw_risk_integral=float(raw[2][6]),raw_peak_risk=float(raw[3][6]),smooth_status=status,repair_attempts=rep,smooth_s=smooth_s,optimizer_and_candidate_validation_s=optimizer_s,raw_roughness_rms_m=float(np.sqrt(np.mean(np.diff(p[:,2]*5,n=2)**2))),smooth_roughness_rms_m=float(np.sqrt(np.mean(np.diff(pp[:,2]*5,n=2)**2))),endpoint_max_error_m=float(np.max(np.linalg.norm(coords(d,pp[[0,-1]])-coords(d,p[[0,-1]]),axis=1))))
 for k,key in enumerate(KEYS):row[key+'_integral']=float(met[2][k])
 row.update(enrich_metrics(d,p.astype(float),pp,raw,met,hard,table))
 row['evaluation_s']=evaluation_before_s+time.perf_counter()-evaluation_started
 row['search_timing_scope']='search plus memory sampler setup and join'
 row['reconstruction_timing_scope']='complete smooth() call including bounds, optimizer, and candidate validation'
 row['evaluation_timing_scope']='evaluation stack, raw and final path metrics, surface metrics, and row preparation; excludes reconstruction and file output'
 if abs(np.dot(W,met[2][:6])-met[2][6])>max(1e-4,met[2][6]*2e-6):raise AssertionError('factor reconstruction failed')
 dirname=OUT/'paths'/table;dirname.mkdir(parents=True,exist_ok=True);np.savez_compressed(dirname/(od['id']+'_'+variant+'.npz'),raw_index=p,index=pp,xyz=xyz)
 record(table,row);print(table,od['id'],variant,'%.1fs'%search_s,'R=%.4f'%row['mean_risk'],status,flush=True)
 del ef,cost;gc.collect()

def enrich_metrics(d,raw_path,path,raw,metrics,nominal_hard,table):
 """Report complete-segment nominal clearance and common objective diagnostics."""
 surface=d['dem']+d['bheight']
 clear,ground,agl,maximum=surface_stats(path,d['dem'],surface)
 rawclear=surface_stats(raw_path,d['dem'],surface)[0]
 rawhits=path_metrics(raw_path,np.empty((0,*nominal_hard.shape),'f4'),nominal_hard)[-1]
 row=dict(min_segment_nominal_surface_clearance_m=float(clear),
          min_segment_nominal_terrain_clearance_m=float(ground),
          avg_agl_m=float(agl),max_agl_m=float(maximum),
          raw_min_segment_nominal_surface_clearance_m=float(rawclear),
          raw_hard_intersections_nominal=int(rawhits),
          raw_population_native_integral=float(raw[2][8]),
          population_density_equivalent_integral_person_m_per_km2=float(metrics[2][8]*100),
          population_density_equivalent_mean_person_per_km2=float(metrics[2][8]/metrics[0]*100),
          verification='all exported segments evaluated in fixed nominal field')
 if table in ['core','benchmark']:
  row.update(raw_objective_nominal_full=float(raw[1]+12*np.dot(W,raw[2][:6])),
             raw_objective_population1=float(raw[1]+12*raw[2][0]),
             raw_objective_population035=float(raw[1]+12*.35*raw[2][0]))
 return row

def constant_agl(d,nom,nomcost,hard,od,table='core'):
 variant='constant_agl60'
 if (od['id'],variant) in done(table):return
 pfile=OUT/'paths'/table/(od['id']+'_uniform.npz')
 if not pfile.exists():record(table,dict(od=od['id'],variant=variant,found=False,failure_reason='uniform projection unavailable'));return
 p=np.load(pfile)['raw_index'].astype(float);ii=p[:,0].astype(int);jj=p[:,1].astype(int);p[:,2]=(d['dem'][ii,jj]+60)/5
 p=np.vstack([np.array(od['start'],float),p,np.array(od['goal'],float)])
 cost=nomcost;ef=evaluation_stack(d,nom,nomcost,cost);met=path_metrics(p,ef,hard)
 row=dict(od=od['id'],variant=variant,found=met[-1]==0,hard_intersections=int(met[-1]),failure_reason='' if met[-1]==0 else 'prescribed AGL on fixed uniform horizontal projection intersects hard cells; not locally raised')
 if met[-1]==0:
  xyz=coords(d,p);agl=xyz[:,2]-d['dem'][np.clip(np.rint(p[:,0]).astype(int),0,len(d['x'])-1),np.clip(np.rint(p[:,1]).astype(int),0,len(d['y'])-1)];ds=np.linalg.norm(np.diff(xyz,axis=0),axis=1)
  row.update(length_m=float(met[0]),risk_integral=float(met[2][6]),mean_risk=float(met[2][6]/met[0]),population_native_integral=float(met[2][8]),population_native_mean=float(met[2][8]/met[0]),peak_risk=float(met[3][6]),objective_discrete=None,avg_agl_m=float(np.average((agl[:-1]+agl[1:])/2,weights=ds)),smooth_status='prescribed cruise, explicit departure/arrival vertical segments')
  for k,key in enumerate(KEYS):row[key+'_integral']=float(met[2][k])
  row.update(enrich_metrics(d,p,p,met,met,hard,table))
  np.savez_compressed(OUT/'paths'/table/(od['id']+'_'+variant+'.npz'),index=p,xyz=coords(d,p))
 else:
  attempted=OUT/'paths'/table
  attempted.mkdir(parents=True,exist_ok=True)
  np.savez_compressed(attempted/(od['id']+'_'+variant+'.npz'),index=p,xyz=coords(d,p))
 record(table,row);del ef;print(table,od['id'],variant,row['found'],flush=True)

def core_configs(extended=True):
 cfg=[('full',W),('uniform',W*0),('population_1',np.array([1,0,0,0,0,0])),('population_035',np.array([.35,0,0,0,0,0])),('population_alt',np.array([.35,.15,0,0,0,0]))]
 for k,key in enumerate(KEYS):w=W.copy();w[k]=0;cfg.append(('fixed_remove_'+key,w))
 if extended:
  for k,key in enumerate(KEYS):w=W.copy();w[k]=0;w/=w.sum();cfg.append(('renorm_remove_'+key,w))
  base=np.array([.35,.15,0,0,0,0])
  for k in [2,3,4,5]:w=base.copy();w[k]=W[k];cfg.append(('add_'+KEYS[k],w))
  for k in [3,4]:w=base.copy();w[2:k+1]=W[2:k+1];cfg.append(('progressive_through_'+KEYS[k],w))
 return cfg
