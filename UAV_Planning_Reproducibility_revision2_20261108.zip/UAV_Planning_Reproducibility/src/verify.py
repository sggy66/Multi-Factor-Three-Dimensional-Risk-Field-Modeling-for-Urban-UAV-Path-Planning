"""Independently validate exported paths, constraints, and planning objectives."""
import csv
import json
from pathlib import Path

import numpy as np

import planner
from kernel import path_metrics, run_tests
from surface import surface_stats


def rows_from(path):
    if path.suffix == '.jsonl':
        return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
    rows = []
    with path.open(encoding='utf-8-sig', newline='') as stream:
        for source in csv.DictReader(stream):
            row = {}
            for key, text in source.items():
                if text is None or text == '':
                    row[key] = None
                elif text in ['True', 'False']:
                    row[key] = text == 'True'
                else:
                    try:
                        row[key] = json.loads(text)
                    except (ValueError, TypeError):
                        row[key] = text
            rows.append(row)
    return rows


def close(name, calculated, saved, differences, absolute=1e-4, relative=3e-6):
    if saved is None:
        return
    difference = abs(float(calculated)-float(saved))
    differences[name] = max(differences.get(name, 0.), difference)
    if difference > max(absolute, abs(float(saved))*relative):
        raise AssertionError(f'{name}: calculated {calculated}, saved {saved}')


def verify_outputs(package, output, tables=None):
    from run import load_inputs, load_configuration, coarsened
    tests = run_tests()
    table_paths = {}
    for name in ['core', 'benchmark', 'ratio', 'joint', 'height_error', 'rain_threshold', 'performance']:
        if tables and name not in tables:
            continue
        path = output / (name + '.jsonl')
        if not path.exists():
            path = output / (name + '.csv')
        if path.exists():
            table_paths[name] = path
    report = dict(algorithm_tests=tests, path_files_checked=0,
                  successful_paths_checked=0, attempted_failed_paths_checked=0,
                  performance_records_without_exported_paths=0,
                  tables=[], maximum_absolute_differences={},
                  scope='complete exported piecewise-linear segments in nominal and applicable planning fields')
    if not table_paths:
        return report
    contract, pairs = load_configuration(package, None)
    pairs = {pair['id']: pair for pair in pairs}
    data = load_inputs(package)
    nominal, hard = planner.fields(data)
    cost = planner.fused(nominal, planner.W)
    surface = data['dem'] + data['bheight']
    native = np.broadcast_to(data['pop'][None, :, :, None], (1, *hard.shape))
    joint_path = package / 'config' / 'joint_parameters.json'
    samples = {sample['id']: sample for sample in json.loads(joint_path.read_text(encoding='utf-8'))} if joint_path.exists() else {}
    configs = dict(planner.core_configs())
    differences = report['maximum_absolute_differences']
    for table, table_path in table_paths.items():
        rows = rows_from(table_path)
        keys = [(row['od'], row['variant']) for row in rows]
        if len(set(keys)) != len(keys):
            raise AssertionError(table + ': duplicate OD/variant records')
        if any(row['od'] not in pairs for row in rows):
            raise AssertionError(table + ': additional OD pairs outside this package scope')
        cases_checked = 0
        cached_variant = None
        own = own_hard = None
        for row in sorted(rows, key=lambda value: (value['variant'], value['od'])):
            filename = output / 'paths' / table / (row['od'] + '_' + row['variant'] + '.npz')
            if not filename.exists():
                if table == 'performance':
                    # The archived performance study stored aggregate records only.
                    # Keep their availability distinct from independent segment checks.
                    report['performance_records_without_exported_paths'] += 1
                    repetitions = row.get('repeat_s') or []
                    if any(not np.isfinite(value) or value < 0 for value in repetitions):
                        raise AssertionError('Invalid performance runtime record')
                    if row.get('length_m') and row.get('risk_integral') is not None:
                        close('performance_record_mean', row['risk_integral']/row['length_m'],
                              row.get('mean_risk'), differences)
                    continue
                if row['found']:
                    raise FileNotFoundError('Successful path file missing: ' + str(filename))
                continue
            with np.load(filename, allow_pickle=False) as archive:
                index = archive['index'].astype(float)
                raw = archive['raw_index'].astype(float) if 'raw_index' in archive else index
                xyz = archive['xyz']
                coarse_index = archive['coarse_index'].astype(float) if 'coarse_index' in archive else None
            report['path_files_checked'] += 1
            if index.ndim != 2 or index.shape[1] != 3 or len(index) < 2 or not np.all(np.isfinite(index)):
                raise AssertionError(filename.name + ': invalid path coordinates')
            close('coordinates', np.max(abs(planner.coords(data, index)-xyz)), 0., differences, 1e-8, 0.)
            expected = np.array([pairs[row['od']]['start'], pairs[row['od']]['goal']])
            close('endpoint_error_m', np.max(abs(index[[0, -1]]-expected))*5, 0., differences, 1e-8, 0.)
            metrics = path_metrics(index, nominal, hard)
            if not row['found']:
                if table != 'core' or row['variant'] != 'constant_agl60' or metrics[-1] == 0:
                    raise AssertionError(filename.name + ': stored failed candidate is unexpectedly valid')
                report['attempted_failed_paths_checked'] += 1
                continue
            cases_checked += 1
            report['successful_paths_checked'] += 1
            integral = float(np.dot(planner.W, metrics[2]))
            close('length_m', metrics[0], row.get('length_m'), differences)
            close('risk_integral', integral, row.get('risk_integral'), differences)
            close('mean_risk', integral/metrics[0], row.get('mean_risk'), differences)
            close('peak_risk', path_metrics(index, cost[None], hard)[3][0], row.get('peak_risk'), differences)
            close('nominal_hard_intersections', metrics[-1], row.get('nominal_hard_intersections'), differences, 0., 0.)
            if table not in ['height_error', 'performance'] and metrics[-1] != 0:
                raise AssertionError(filename.name + ': nominal hard constraint violation')
            for key, value in zip(planner.KEYS, metrics[2]):
                close(key+'_integral', value, row.get(key+'_integral'), differences)
            population = path_metrics(index, native, hard)[2][0]
            close('population_native_integral', population, row.get('population_native_integral'), differences)
            close('population_native_mean', population/metrics[0], row.get('population_native_mean'), differences)
            clear, ground, agl, maximum = surface_stats(index, data['dem'], surface)
            for key, value in [('min_segment_nominal_surface_clearance_m', clear),
                               ('min_segment_nominal_terrain_clearance_m', ground),
                               ('avg_agl_m', agl), ('max_agl_m', maximum)]:
                close(key, value, row.get(key), differences)
            if table == 'performance':
                close('connector_hard_intersections', metrics[-1], row.get('connector_hard_intersections'), differences, 0., 0.)
                if row.get('common_endpoints_feasible') != (metrics[-1] == 0):
                    raise AssertionError(filename.name + ': inconsistent connector feasibility flag')
                if coarse_index is not None:
                    resolution = row['resolution_m']
                    coarse_cost, coarse_hard = coarsened(cost, hard, int(resolution//5))
                    coarse_metrics = path_metrics(coarse_index, coarse_cost[None], coarse_hard, float(resolution))
                    if coarse_metrics[-1] != 0:
                        raise AssertionError(filename.name + ': coarse hard constraint violation')
                    close('performance_objective', coarse_metrics[1]+12*coarse_metrics[2][0], row.get('objective'), differences)
                continue
            if row['variant'] == 'constant_agl60':
                continue
            if cached_variant != row['variant']:
                cached_variant = row['variant']
                if table == 'joint':
                    sample = samples[row['variant']]
                    channels, own_hard = planner.fields(data, sample['params'])
                    own = planner.fused(channels, np.array(sample['weights']))
                    del channels
                elif table == 'height_error':
                    response = planner.PARAM.copy()
                    prefix = next(key for key in ['terrain_shift', 'building_shift'] if row['variant'].startswith(key))
                    response[prefix] = float(row['variant'][len(prefix):])
                    channels, own_hard = planner.fields(data, response)
                    own = planner.fused(channels, np.array(row['weights']))
                    del channels
                elif table == 'rain_threshold':
                    response = planner.PARAM.copy()
                    response['rain_hard'] = True
                    channels, own_hard = planner.fields(data, response)
                    own = planner.fused(channels, np.array(row['weights']))
                    del channels
                else:
                    own_hard = hard
                    own = planner.fused(nominal, np.array(row['weights']))
            own_metrics = path_metrics(index, own[None], own_hard)
            if own_metrics[-1] != 0:
                raise AssertionError(filename.name + ': planning hard constraint violation')
            close('hard_intersections', own_metrics[-1], row.get('hard_intersections'), differences, 0., 0.)
            close('own_risk_integral', own_metrics[2][0], row.get('own_risk_integral'), differences)
            raw_metrics = path_metrics(raw, own[None], own_hard)
            if raw_metrics[-1] != 0:
                raise AssertionError(filename.name + ': raw path planning hard constraint violation')
            objective = raw_metrics[1] + row['rho']*raw_metrics[2][0]
            close('objective_discrete', objective, row.get('objective_discrete'), differences)
            close('objective_independent', objective, row.get('objective_independent'), differences)
            close('movement_discrete', raw_metrics[1], row.get('movement_discrete'), differences)
            close('risk_term_discrete', row['rho']*raw_metrics[2][0], row.get('risk_term_discrete'), differences)
            raw_nominal = path_metrics(raw, nominal, hard)
            close('raw_length_m', raw_nominal[0], row.get('raw_length_m'), differences)
            close('raw_risk_integral', np.dot(planner.W, raw_nominal[2]), row.get('raw_risk_integral'), differences)
            if row.get('smooth_status', '').startswith('accepted'):
                if metrics[0] > raw_nominal[0]*1.01+1e-6 or integral > np.dot(planner.W, raw_nominal[2])*1.01+1e-4:
                    raise AssertionError(filename.name + ': reconstruction length/integral acceptance rule exceeded')
        report['tables'].append(dict(table=table, rows=len(rows), successful_paths_checked=cases_checked))
    return report
