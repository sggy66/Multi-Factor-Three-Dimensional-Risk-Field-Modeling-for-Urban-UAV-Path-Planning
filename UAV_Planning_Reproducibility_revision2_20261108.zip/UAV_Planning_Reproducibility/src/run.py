"""Run the six preselected OD pairs from unchanged processed inputs."""
from pathlib import Path
import argparse
import gc
import importlib.metadata
import json
import math
import platform
import sys
import time

import numpy as np
import psutil

import planner
from kernel import search, path_metrics, run_tests
from surface import surface_stats

PACKAGE = Path(__file__).resolve().parents[1]
REQUIRED = ('x', 'y', 'z', 'valid', 'dem', 'pop', 'pop_norm', 'rain',
            'bheight', 'bmask', 'nearest_ix', 'nearest_iy', 'dbld',
            'droad', 'dwater', 'nfz')


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding='utf-8')


def environment():
    versions = {}
    for name in ['numpy', 'scipy', 'numba', 'psutil']:
        versions[name] = importlib.metadata.version(name)
    return dict(python=platform.python_version(), platform=platform.platform(),
                processor=platform.processor(), logical_cpus=psutil.cpu_count(),
                physical_cpus=psutil.cpu_count(logical=False),
                physical_memory_gib=psutil.virtual_memory().total / 2**30,
                packages=versions, jit_cache='Numba disk cache enabled',
                rss_scope='whole Python process, including inputs, fields, and imported libraries',
                rss_sampling_interval_s=.02)


def load_inputs(package):
    with np.load(package / 'data' / 'planning_inputs.npz', allow_pickle=False) as archive:
        missing = set(REQUIRED) - set(archive.files)
        if missing:
            raise ValueError('Missing processed input arrays: ' + ', '.join(sorted(missing)))
        data = {key: archive[key] for key in REQUIRED}
    shape = (len(data['x']), len(data['y']))
    for key in REQUIRED[3:]:
        if data[key].shape != shape:
            raise ValueError(f'{key}: expected horizontal shape {shape}, got {data[key].shape}')
    for key, step in [('x', 5.), ('y', -5.), ('z', 5.)]:
        if not np.allclose(np.diff(data[key]), step, rtol=0, atol=1e-8):
            raise ValueError('Processed planning inputs must use the archived 5 m grid')
    if not np.isclose(data['z'][0], 0):
        raise ValueError('The archived vertical grid starts at absolute z = 0 m')
    for key in ['dem', 'pop', 'pop_norm', 'rain', 'bheight', 'dbld', 'droad', 'dwater']:
        if not np.all(np.isfinite(data[key][data['valid']])):
            raise ValueError(f'{key}: non-finite values in the study domain')
    for key, maximum in [('nearest_ix', shape[0]), ('nearest_iy', shape[1])]:
        if np.any(data[key] < 0) or np.any(data[key] >= maximum):
            raise ValueError(f'{key}: indices outside the planning grid')
    return data


def warm_planning_signatures():
    """Load or compile the signatures used by the full-sized nominal workflow."""
    field = np.full((3, 3, 3), .3, dtype='f4')
    hard = np.zeros(field.shape, dtype=bool)
    start = np.array([0, 0, 1], dtype=np.int64)
    goal = np.array([2, 2, 1], dtype=np.int64)
    path, _, _ = search(field, hard, start, goal, 5., 12., 2.5, 160)
    path = path.astype(float)
    stack = np.repeat(field[None], 9, axis=0)
    path_metrics(path, stack, hard)
    path_metrics(path, np.empty((0, *hard.shape), dtype='f4'), hard)
    ground = np.zeros(field.shape[:2], dtype='f4')
    surface_stats(path, ground, ground)


def load_configuration(package, od_selection):
    contract_path = package / 'config' / 'experiment.json'
    contract = json.loads(contract_path.read_text(encoding='utf-8')) if contract_path.exists() else {}
    if 'weights' in contract:
        weights = np.asarray(contract['weights'], float)
        if weights.shape != (6,) or np.any(weights < 0):
            raise ValueError('weights must contain six non-negative values')
        if not np.allclose(weights, [.35, .15, .15, .15, .1, .1]):
            raise ValueError('This package reproduces the archived nominal weights')
        planner.W[:] = weights
    planner.RHO = float(contract.get('rho_nominal', 12))
    if planner.RHO != 12 or float(contract.get('vertical_multiplier', 2.5)) != 2.5:
        raise ValueError('The archived nominal coefficients are rho = 12 and vertical multiplier = 2.5')
    supplied = contract.get('response_parameters', contract.get('parameters', {}))
    unknown = set(supplied) - set(planner.PARAM)
    if unknown:
        raise ValueError('Unknown response parameters: ' + ', '.join(sorted(unknown)))
    planner.PARAM.update(supplied)
    all_pairs = json.loads((package / 'config' / 'od_pairs.json').read_text(encoding='utf-8'))
    if isinstance(all_pairs, dict):
        all_pairs = all_pairs['pairs']
    if len(all_pairs) != 6 or {r['id'] for r in all_pairs} != {f'OD{k:02d}' for k in range(1, 7)}:
        raise ValueError('od_pairs.json must contain the six preselected OD01 through OD06 pairs')
    selected = [r for r in all_pairs if not od_selection or r['id'] in od_selection]
    for row in selected:
        for key in ['start', 'goal']:
            if len(row[key]) != 3 or any(int(v) != v for v in row[key]):
                raise ValueError('Endpoint indices must contain three integers')
    return contract, selected


def core(data, nominal, cost, hard, pairs, variants=None):
    configs = planner.core_configs()
    available = {name for name, _ in configs} | {'constant_agl60'}
    if variants and set(variants) - available:
        raise ValueError('Unknown core variants: ' + ', '.join(sorted(set(variants) - available)))
    for pair in pairs:
        for name, weights in configs:
            if variants and name not in variants:
                continue
            planner.solve(data, nominal, cost, hard, pair, name, weights)
        if not variants or 'constant_agl60' in variants:
            if not (planner.OUT / 'paths' / 'core' / (pair['id'] + '_uniform.npz')).exists():
                planner.solve(data, nominal, cost, hard, pair, 'uniform', planner.W * 0)
            planner.constant_agl(data, nominal, cost, hard, pair)


def robustness(data, nominal, cost, hard, pairs, contract, analyses, joint_limit, package):
    analyses = set(analyses or ['ratio', 'joint', 'height_error', 'rain_threshold'])
    if 'ratio' in analyses:
        for rho in contract.get('ratio_values', [3, 6, 12, 24, 48]):
            for pair in pairs:
                for name, weights in [('full', planner.W),
                                      ('population_1', np.array([1, 0, 0, 0, 0, 0])),
                                      ('population_035', np.array([.35, 0, 0, 0, 0, 0]))]:
                    planner.solve(data, nominal, cost, hard, pair, name + '_rho' + str(rho),
                                  weights, rho, table='ratio', smoothing=False)
    if 'joint' in analyses:
        samples = json.loads((package / 'config' / 'joint_parameters.json').read_text(encoding='utf-8'))
        if len(samples) != 40 or {s['id'] for s in samples} != {f'J{k:02d}' for k in range(40)}:
            raise ValueError('joint_parameters.json must contain the archived 40 settings')
        if joint_limit is not None:
            samples = samples[:joint_limit]
        for sample in samples:
            if all((pair['id'], sample['id']) in planner.done('joint') for pair in pairs):
                continue
            own, own_hard = planner.fields(data, sample['params'])
            for pair in pairs:
                planner.solve(data, nominal, cost, hard, pair, sample['id'],
                              np.array(sample['weights']), sample['rho'], own, own_hard,
                              table='joint', smoothing=False)
            del own, own_hard
            gc.collect()
    if 'height_error' in analyses:
        for key in ['terrain_shift', 'building_shift']:
            for shift in contract.get('error_shifts_m', [-10, -5, 5, 10]):
                response = planner.PARAM.copy()
                response[key] = shift
                own, own_hard = planner.fields(data, response)
                for pair in pairs:
                    variant = key + str(shift)
                    planner.solve(data, nominal, cost, hard, pair, variant,
                                  planner.W, planner.RHO, own, own_hard,
                                  table='height_error', smoothing=False)
                    base_file = planner.OUT / 'paths' / 'core' / (pair['id'] + '_full.npz')
                    if not base_file.exists():
                        planner.solve(data, nominal, cost, hard, pair, 'full')
                    with np.load(base_file, allow_pickle=False) as archive:
                        index = archive['index']
                    metrics = path_metrics(index.astype(float), nominal, own_hard)
                    if (pair['id'], variant) not in planner.done('fixed_path_error'):
                        planner.record('fixed_path_error', dict(
                            od=pair['id'], variant=variant,
                            hard_intersections=int(metrics[-1]), found=metrics[-1] == 0,
                            length_m=float(metrics[0])))
                del own, own_hard
                gc.collect()
    if 'rain_threshold' in analyses:
        response = planner.PARAM.copy()
        response['rain_hard'] = True
        own, own_hard = planner.fields(data, response)
        for pair in pairs:
            planner.solve(data, nominal, cost, hard, pair, 'rain_threshold500_on',
                          planner.W, planner.RHO, own, own_hard,
                          table='rain_threshold', smoothing=False)


def coarsened(cost, hard, q):
    limits = [value // q * q for value in hard.shape]
    window = tuple(slice(0, value) for value in limits)
    coarse_hard = hard[window]
    coarse_cost = cost[window]
    if q > 1:
        shape = (limits[0] // q, q, limits[1] // q, q, limits[2] // q, q)
        coarse_hard = coarse_hard.reshape(shape).any(axis=(1, 3, 5))
        coarse_cost = coarse_cost.reshape(shape).mean(axis=(1, 3, 5))
    return coarse_cost, coarse_hard


def performance(data, nominal, cost, hard, pairs, contract, resolutions, margins):
    resolutions = resolutions or contract.get('performance_resolution_m', [5, 10, 20])
    margins = margins or contract.get('performance_margin_m', [800, 1200, 1600])
    for resolution in resolutions:
        q = int(resolution // 5)
        if resolution not in [5, 10, 20]:
            raise ValueError('Performance resolution must be 5, 10, or 20 m')
        started = time.perf_counter()
        coarse_cost, coarse_hard = coarsened(cost, hard, q)
        aggregation_s = time.perf_counter() - started
        for pair in pairs:
            endpoints = []
            for raw in [pair['start'], pair['goal']]:
                ij = np.clip(np.floor(np.array(raw[:2]) / q).astype(int),
                             0, np.array(coarse_hard.shape[:2]) - 1)
                heights = np.flatnonzero(~coarse_hard[ij[0], ij[1]])
                endpoints.append(np.array([ij[0], ij[1], int(heights[0])]) if len(heights) else None)
            for margin in margins:
                variant = f'res{resolution}_margin{margin}'
                if (pair['id'], variant) in planner.done('performance'):
                    continue
                if any(point is None for point in endpoints):
                    planner.record('performance', dict(
                        od=pair['id'], variant=variant, found=False,
                        resolution_m=resolution, margin_m=margin,
                        failure_reason='coarse endpoint column unavailable'))
                    continue
                times = []
                peak = 0
                for repetition in range(3):
                    with planner.PeakMemory() as memory:
                        started = time.perf_counter()
                        path, objective, nodes = search(
                            coarse_cost, coarse_hard, endpoints[0], endpoints[1],
                            resolution, planner.RHO, 2.5, math.ceil(margin / resolution))
                        times.append(time.perf_counter() - started)
                    peak = max(peak, memory.peak)
                row = dict(od=pair['id'], variant=variant, found=bool(len(path)),
                           resolution_m=resolution, margin_m=margin,
                           aggregation_s=aggregation_s, repeat_s=times,
                           initial_call_s=times[0], warmed_repeat_s=times[1:],
                           median_s=float(np.median(times[1:])),
                           peak_rss_mib=peak / 2**20, nodes=int(nodes),
                           objective=float(objective) if np.isfinite(objective) else None,
                           timing_scope='first call and median of two subsequent calls; prior stage warmup is recorded separately')
                if len(path):
                    fine = path.astype(float) * q + (q - 1) / 2
                    offsets = np.linalg.norm((fine[[0, -1]] - np.array([pair['start'], pair['goal']])) * 5, axis=1)
                    connected = np.vstack([pair['start'], fine, pair['goal']])
                    metrics = path_metrics(connected, nominal, hard)
                    integral = float(np.dot(planner.W, metrics[2]))
                    row.update(endpoint_offsets_m=offsets.tolist(),
                               connector_hard_intersections=int(metrics[-1]),
                               common_endpoints_feasible=metrics[-1] == 0,
                               length_m=float(metrics[0]), risk_integral=integral,
                               mean_risk=integral / metrics[0],
                               scope='coarse search plus explicit original-endpoint connectors; state graphs differ')
                    directory = planner.OUT / 'paths' / 'performance'
                    directory.mkdir(parents=True, exist_ok=True)
                    np.savez_compressed(directory / (pair['id'] + '_' + variant + '.npz'),
                                        coarse_index=path, index=connected,
                                        xyz=planner.coords(data, connected))
                else:
                    row['failure_reason'] = 'no path in the conservatively aggregated search graph'
                planner.record('performance', row)
                print('performance', pair['id'], variant, times, flush=True)


def run_benchmark(data, nominal, cost, hard, pairs):
    if planner.done('benchmark'):
        raise ValueError('Benchmark output exists; choose a fresh --output directory for new timing measurements')
    reports = []
    for pair in pairs:
        started = time.perf_counter()
        with planner.PeakMemory() as memory:
            planner.solve(data, nominal, cost, hard, pair, 'full', table='benchmark')
        elapsed = time.perf_counter() - started
        row = next(r for r in read_rows(planner.OUT / 'benchmark.jsonl') if r['od'] == pair['id'])
        stage_total = row['search_s'] + row.get('smooth_s', 0) + row.get('evaluation_s', 0)
        reports.append(dict(od=pair['id'], found=row['found'],
                            search_s=row['search_s'], reconstruction_s=row.get('smooth_s', 0),
                            evaluation_s=row.get('evaluation_s', 0),
                            other_verification_and_output_s=max(0., elapsed-stage_total),
                            route_workflow_s=elapsed,
                            route_peak_process_rss_mib=memory.peak/2**20,
                            scope='one full-model route after shared input loading, field construction, and warmup'))
    return reports


def read_rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', choices=['core', 'robust', 'performance', 'benchmark', 'verify', 'all'], default='core')
    parser.add_argument('--package', type=Path, default=PACKAGE, help='directory containing config/ and data/')
    parser.add_argument('--output', type=Path, default=PACKAGE / 'runs', help='output directory; existing cases are resumed')
    parser.add_argument('--report', type=Path, help='verification report path; default: runs/verification.json')
    parser.add_argument('--od', choices=[f'OD{k:02d}' for k in range(1, 7)], nargs='+', default=['OD01', 'OD02'], help='default: original OD01 and OD02; specify all six for the extended comparison')
    parser.add_argument('--variant', nargs='+', help='core stage only: select named model configurations')
    parser.add_argument('--analysis', choices=['ratio', 'joint', 'height_error', 'rain_threshold'], nargs='+', help='robust stage only')
    parser.add_argument('--joint-limit', type=int, choices=range(1, 41), metavar='1..40', help='optional partial run of the frozen joint settings')
    parser.add_argument('--resolution', type=int, choices=[5, 10, 20], nargs='+', help='performance stage only')
    parser.add_argument('--margin', type=int, choices=[800, 1200, 1600], nargs='+', help='performance stage only')
    parser.add_argument('--table', choices=['core', 'benchmark', 'ratio', 'joint', 'height_error', 'rain_threshold', 'performance'],
                        nargs='+', help='verify stage only: select output tables')
    return parser.parse_args()


def main():
    args = parse_args()
    planner.OUT = args.output.resolve()
    planner.OUT.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    with planner.PeakMemory() as workflow_memory:
        metadata = environment()
        if args.stage == 'verify':
            from verify import verify_outputs
            report = verify_outputs(args.package, planner.OUT, args.table)
            write_json(args.report or PACKAGE / 'runs' / 'verification.json', report)
            print(f"Verified {report['path_files_checked']} exported path files and {len(report['algorithm_tests'])} algorithm checks", flush=True)
            return
        contract, pairs = load_configuration(args.package, args.od)
        timer = time.perf_counter()
        data = load_inputs(args.package)
        metadata['input_loading_s'] = time.perf_counter() - timer
        timer = time.perf_counter()
        nominal, hard = planner.fields(data)
        cost = planner.fused(nominal, planner.W)
        metadata['field_construction_s'] = time.perf_counter() - timer
        timer = time.perf_counter()
        tests = run_tests()
        metadata['initial_kernel_tests_and_cache_load_s'] = time.perf_counter() - timer
        timer = time.perf_counter()
        warm_planning_signatures()
        metadata['planning_signature_warmup_s'] = time.perf_counter() - timer
        write_json(planner.OUT / 'algorithm_tests.json', tests)
        for pair in pairs:
            for key in ['start', 'goal']:
                point = np.asarray(pair[key])
                if np.any(point < 0) or np.any(point >= np.asarray(hard.shape)):
                    raise ValueError(pair['id'] + ': endpoint outside the planning grid')
        if args.stage in ['core', 'all']:
            core(data, nominal, cost, hard, pairs, args.variant)
        if args.stage in ['robust', 'all']:
            robustness(data, nominal, cost, hard, pairs, contract, args.analysis, args.joint_limit, args.package)
        if args.stage in ['performance', 'all']:
            performance(data, nominal, cost, hard, pairs, contract, args.resolution, args.margin)
        if args.stage == 'benchmark':
            metadata['routes'] = run_benchmark(data, nominal, cost, hard, pairs)
        metadata.update(stage=args.stage, selected_pairs=[pair['id'] for pair in pairs],
                        weights=planner.W.tolist(), rho_nominal=planner.RHO,
                        response_parameters=planner.PARAM,
                        complete_workflow_s=time.perf_counter()-started,
                        timing_start='main() entry after module imports; includes input loading, fields, kernel tests, planning, verification, and output')
    metadata['peak_process_rss_mib'] = workflow_memory.peak / 2**20
    write_json(planner.OUT / ('runtime_' + args.stage + '.json'), metadata)
    print('STAGE COMPLETE', args.stage, flush=True)


if __name__ == '__main__':
    main()
