"""Paired frozen-parameter tests, then spatially confined height-error tests."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,csv,gc,hashlib,json,sys,time
import numpy as np
from numba import njit

PACKAGE=Path(__file__).resolve().parents[1]
CONFIG=PACKAGE/'config'
ROOT=PACKAGE/'runs'/'followup'
BASE=PACKAGE/'results'/'six_od'
sys.path.insert(0,str(PACKAGE/'src'))
import planner
from kernel import search,path_metrics,segment_cells,run_tests
from surface import surface_stats
from run import load_inputs,environment,warm_planning_signatures

W=np.array([.35,.15,.15,.15,.1,.1])
MODELS=['full','population_alt']
FACTOR_KEYS=['pop','alt','road','bld','wth','riv']
INNER=100.;OUTER=200.

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(p,value):
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    tmp.replace(p)
def read_rows(name):
    p=ROOT/'results'/(name+'.jsonl')
    return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines()] if p.exists() else []
def append(name,row):
    with (ROOT/'results'/(name+'.jsonl')).open('a',encoding='utf-8') as f:f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n')
def path_file(stage,case,od,model):return ROOT/'results'/'paths'/stage/f'{case}_{od}_{model}.npz'
def coordinates(d,p):return np.column_stack([d['x'][0]+p[:,0]*5,d['y'][0]-p[:,1]*5,p[:,2]*5])

@njit(cache=True)
def regional_clearance(p,dem,surface,region):
    minimum=1e100;terrain_min=1e100;length_inside=0.
    for k in range(len(p)-1):
        a=p[k];b=p[k+1];dv=b-a;L=np.sqrt(np.sum(dv*dv))*5
        if L<1e-12:continue
        ts=segment_cells(a,b)
        for j in range(len(ts)-1):
            if ts[j+1]-ts[j]<1e-12:continue
            mid=a+.5*(ts[j+1]+ts[j])*dv;ix=int(np.floor(mid[0]+.5));iy=int(np.floor(mid[1]+.5))
            if not region[ix,iy]:continue
            lo=min(a[2]+ts[j]*dv[2],a[2]+ts[j+1]*dv[2])*5
            minimum=min(minimum,lo-surface[ix,iy]);terrain_min=min(terrain_min,lo-dem[ix,iy]);length_inside+=(ts[j+1]-ts[j])*L
        for j in range(2*len(ts)-1):
            t=ts[j//2] if j%2==0 else .5*(ts[j//2]+ts[j//2+1]);m=a+t*dv
            ix=int(np.floor(m[0]+.5));iy=int(np.floor(m[1]+.5))
            for xx in range(ix-1 if abs(m[0]+.5-round(m[0]+.5))<1e-8 else ix,ix+1):
                for yy in range(iy-1 if abs(m[1]+.5-round(m[1]+.5))<1e-8 else iy,iy+1):
                    if xx>=0 and yy>=0 and xx<dem.shape[0] and yy<dem.shape[1] and region[xx,yy]:
                        minimum=min(minimum,m[2]*5-surface[xx,yy]);terrain_min=min(terrain_min,m[2]*5-dem[xx,yy])
    return minimum,terrain_min,length_inside

def clean_clearance(value):return float(value) if value<1e90 else None
def spatial_profile(d,points):
    x=d['x'][:,None];y=d['y'][None,:]
    distance=np.full(d['valid'].shape,np.inf)
    for p in points.values():distance=np.minimum(distance,np.hypot(x-d['x'][p[0]],y-d['y'][p[1]]))
    u=np.clip((distance-INNER)/(OUTER-INNER),0,1)
    multiplier=(.5-.5*np.cos(np.pi*u)).astype('f4')
    multiplier[distance<=INNER]=0;multiplier[distance>=OUTER]=1
    region=np.ascontiguousarray((distance>=OUTER)&d['valid'])
    return distance,multiplier,region

def localized_data(d,factor,bias,multiplier):
    out=d.copy()
    if factor=='terrain':out['dem']=d['dem']+bias*multiplier
    elif factor=='building':out['bheight']=np.where(d['bmask'],np.maximum(d['bheight']+bias*multiplier,0),0).astype(d['bheight'].dtype)
    else:raise ValueError(factor)
    return out

def case_metrics(p,d,nominal,nomcost,nomhard,owncost,ownhard,surface_data=None,region=None):
    nominal_metric=path_metrics(p,nominal,nomhard)
    common=path_metrics(p,nomcost[None],nomhard)
    own=path_metrics(p,owncost[None],ownhard)
    pop=np.broadcast_to(d['pop'][None,:,:,None],(1,*nomhard.shape))
    population=path_metrics(p,pop,nomhard)[2][0]
    sd=d if surface_data is None else surface_data
    surface=sd['dem']+sd['bheight']
    clear,ground,agl,maximum=surface_stats(p,sd['dem'],surface)
    out=dict(length_m=float(common[0]),movement=float(own[1]),nominal_integral=float(common[2][0]),
             nominal_mean=float(common[2][0]/common[0]),nominal_peak=float(common[3][0]),
             own_integral=float(own[2][0]),population_native_mean=float(population/common[0]),
             population_native_integral=float(population),nominal_hard_hits=int(common[-1]),
             planning_hard_hits=int(own[-1]),min_clearance_m=float(clear),min_terrain_clearance_m=float(ground),
             mean_agl_m=float(agl),max_agl_m=float(maximum))
    for i,key in enumerate(FACTOR_KEYS):out[key+'_nominal_weighted_integral']=float(W[i]*nominal_metric[2][i])
    difference=sum(out[key+'_nominal_weighted_integral'] for key in FACTOR_KEYS)-out['nominal_integral']
    assert abs(difference)<=max(1e-4,abs(out['nominal_integral'])*2e-6)
    out['factor_sum_error']=float(difference)
    if region is not None:
        ci,gi,li=regional_clearance(p,sd['dem'],surface,region)
        out.update(interior_min_clearance_m=clean_clearance(ci),interior_min_terrain_clearance_m=clean_clearance(gi),interior_path_length_m=float(li))
    return out

def solve_case(stage,case,d,nominal,nomcost,nomhard,owncost,ownhard,pair,model,weights,rho,surface_data=None,region=None):
    start=np.array(pair['start'],dtype=np.int64);goal=np.array(pair['goal'],dtype=np.int64)
    t=time.perf_counter()
    p,J,n=search(owncost,ownhard,start,goal,5.,float(rho),2.5,160)
    elapsed=time.perf_counter()-t
    row=dict(stage=stage,case_id=case,od=pair['id'],model=model,found=bool(len(p)),weights=np.asarray(weights).tolist(),rho=float(rho),
             search_s=elapsed,closed_nodes=int(n),reconstruction=False,
             start_blocked=bool(ownhard[tuple(start)]),goal_blocked=bool(ownhard[tuple(goal)]))
    if len(p):
        p=p.astype(float)
        assert np.array_equal(p[[0,-1]],np.array([pair['start'],pair['goal']]))
        row.update(case_metrics(p,d,nominal,nomcost,nomhard,owncost,ownhard,surface_data,region))
        independent=row['movement']+rho*row['own_integral']
        assert row['planning_hard_hits']==0
        assert abs(independent-J)<=max(1e-5,abs(J)*1e-7),(case,pair['id'],model,independent,J)
        row.update(objective=float(J),objective_independent=float(independent),endpoint_error_m=0.)
        dest=path_file(stage,case,pair['id'],model);dest.parent.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(dest,index=p,xyz=coordinates(d,p))
    else:
        row['failure_reason']='blocked endpoint' if row['start_blocked'] or row['goal_blocked'] else 'no path in fixed bounded corridor'
    append(stage,row)
    print(stage,case,pair['id'],model,'found' if row['found'] else row['failure_reason'],f'{elapsed:.2f}s',flush=True)
    return row

def tests_new_geometry():
    dem=np.zeros((3,3),'f4');surf=np.full((3,3),2.,'f4');region=np.ones((3,3),np.bool_)
    p=np.array([[1.,1.,1.],[1.,1.,2.]])
    v=regional_clearance(p,dem,surf,region)
    assert abs(v[0]-3)<1e-9 and abs(v[2]-5)<1e-9
    region[:]=False;assert regional_clearance(p,dem,surf,region)[0]>1e90
    region[:]=True
    assert abs(regional_clearance(p,dem,surf,region)[0]-surface_stats(p,dem,surf)[0])<1e-9
    region[:]=False;region[0,:]=True;surf[0,:]=8
    p=np.array([[.5,.1,1.],[.5,1.1,1.]])
    assert abs(regional_clearance(p,dem,surf,region)[0]+3)<1e-9
    return ['regional_constant_vertical','empty_region_not_zero_clearance','all_region_agrees_with_surface_stats','boundary_contact_in_selected_region']

def freeze_plan(pairs,samples):
    inputs=[PACKAGE/'data'/'planning_inputs.npz',CONFIG/'od_pairs.json',CONFIG/'points.json',CONFIG/'joint_parameters.json']
    inputs+=list((PACKAGE/'src').glob('*.py'))+[Path(__file__)]
    inputs+=sorted((BASE/'paths'/'core').glob('*.npz'))
    source_hashes={p.relative_to(PACKAGE).as_posix():sha(p) for p in inputs}
    plan=dict(pairs=pairs,sample_ids=[s['id'] for s in samples],models=MODELS,joint_cases=480,height_replanning_cases=96,
              joint_shared_weights='identical sampled population and altitude weights; other four zero for population_alt; no renormalization',
              parameter_samples='unchanged archived 40 settings',nominal_weights=W.tolist(),risk_distance_nominal=12.,grid_m=5.,corridor_margin_m=800.,
              primary_comparison='fixed nominal six-factor integral; positive paired benefit means full model lower',
              tie_absolute_integral=1e-4,tie_relative_integral=1e-6,reconstruction=False,
              endpoint_protection_inner_m=INNER,endpoint_protection_outer_m=OUTER,
              height_profile='0 within 100 m of any of the four original endpoints; raised cosine between 100 and 200 m; 1 beyond 200 m',
              height_factors=['terrain','building'],height_bias_m=[-10.,-5.,5.,10.],
              height_building_rule='only footprint cells shifted; heights clipped at zero; terrain shift also shifts roof elevations',
              fixed_paths='both archived raw and reconstructed nominal paths revalidated; reconstructed route is primary fixed-path result',
              clearance_reference='perturbed modeled terrain and roofs; both whole route and full-amplitude interior reported',
              sources=source_hashes)
    path=ROOT/'config'/'followup_plan.json'
    if path.exists():assert json.loads(path.read_text(encoding='utf-8'))==plan,'Frozen plan or source changed; use a new experiment directory.'
    else:write_json(path,plan)
    return plan

def progress(stage,case=None):
    write_json(ROOT/'results'/'progress.json',dict(stage=stage,case=case,joint_completed=len(read_rows('joint_paired')),joint_expected=480,
               height_completed=len(read_rows('height_interior')),height_expected=96,updated_utc=datetime.now(timezone.utc).isoformat()))

def run_joint(d,nominal,nomcost,nomhard,pairs,samples,selected=None):
    done={(r['case_id'],r['od'],r['model']) for r in read_rows('joint_paired')}
    for sample in samples:
        if selected and sample['id'] not in selected:continue
        if all((sample['id'],p['id'],m) in done for p in pairs for m in MODELS):continue
        channels,hh=planner.fields(d,sample['params'])
        assert np.array_equal(hh,nomhard),'Joint samples unexpectedly change the feasible graph'
        weights=np.array(sample['weights']);simple=weights.copy();simple[2:]=0
        costs={'full':planner.fused(channels,weights),'population_alt':planner.fused(channels,simple)}
        del channels;gc.collect()
        for pair in pairs:
            for model in MODELS:
                key=sample['id'],pair['id'],model
                if key in done:continue
                row=solve_case('joint_paired',sample['id'],d,nominal,nomcost,nomhard,costs[model],hh,pair,model,weights if model=='full' else simple,sample['rho'])
                if model=='full' and pair['id'] in ['OD01','OD02']:
                    archive=PACKAGE/'results'/'reference'/'paths'/'joint'/f'{pair["id"]}_{sample["id"]}.npz'
                    if row['found'] and archive.exists():
                        with np.load(archive,allow_pickle=False) as old,np.load(path_file('joint_paired',sample['id'],pair['id'],model)) as new:
                            assert np.array_equal(old['index'],new['index']),'Archived full-model path did not reproduce'
                        row=dict(od=pair['id'],case_id=sample['id'],archived_path_exact=True)
                        append('original_joint_reproduction',row)
                done.add(key);progress('joint_paired',sample['id'])
        del costs,hh;gc.collect()
    progress('joint_paired_complete' if len(done)==480 else 'joint_paired_partial')

def height_scenarios():
    for factor in ['terrain','building']:
        for bias in [-10.,-5.,5.,10.]:yield factor,bias,f'{factor}_{"m" if bias<0 else "p"}{int(abs(bias)):02d}'

def run_height(d,nominal,nomcost,nomhard,pairs,points):
    distance,multiplier,region=spatial_profile(d,points)
    assert np.all(multiplier[distance<=INNER]==0) and np.all(multiplier[distance>=OUTER]==1)
    for point in points.values():assert multiplier[point[0],point[1]]==0
    np.savez_compressed(ROOT/'config'/'height_spatial_profile.npz',distance_m=distance,multiplier=multiplier,full_amplitude_region=region)
    done={(r['case_id'],r['od'],r['model']) for r in read_rows('height_interior')}
    fixdone={(r['case_id'],r['od'],r['model']) for r in read_rows('fixed_path_interior')}
    for factor,bias,case in height_scenarios():
        dd=localized_data(d,factor,bias,multiplier)
        channels,hh=planner.fields(dd)
        for point in points.values():assert hh[tuple(point)]==nomhard[tuple(point)]==False
        costs={'full':planner.fused(channels,W),'population_alt':planner.fused(channels,np.array([.35,.15,0,0,0,0]))}
        del channels;gc.collect()
        for pair in pairs:
            for model in MODELS:
                key=case,pair['id'],model
                if key not in fixdone:
                    with np.load(BASE/'paths'/'core'/f'{pair["id"]}_{model}.npz',allow_pickle=False) as base:
                        p=base['index'];raw=base['raw_index'].astype(float)
                    q=path_metrics(p,np.empty((0,*hh.shape),'f4'),hh)
                    qr=path_metrics(raw,np.empty((0,*hh.shape),'f4'),hh)
                    sf=dd['dem']+dd['bheight']
                    ci=regional_clearance(p,dd['dem'],sf,region)
                    row=dict(case_id=case,od=pair['id'],model=model,factor=factor,bias_m=bias,
                             hard_hits=int(q[-1]),feasible=q[-1]==0,raw_hard_hits=int(qr[-1]),raw_feasible=qr[-1]==0,
                             min_clearance_m=float(surface_stats(p,dd['dem'],sf)[0]),
                             interior_min_clearance_m=clean_clearance(ci[0]),interior_path_length_m=float(ci[2]),
                             start_blocked=bool(hh[tuple(pair['start'])]),goal_blocked=bool(hh[tuple(pair['goal'])]))
                    append('fixed_path_interior',row);fixdone.add(key)
                if key not in done:
                    weights=W if model=='full' else np.array([.35,.15,0,0,0,0])
                    row=solve_case('height_interior',case,d,nominal,nomcost,nomhard,costs[model],hh,pair,model,weights,12.,dd,region)
                    append('height_case_metadata',dict(case_id=case,od=pair['id'],model=model,factor=factor,bias_m=bias))
                    done.add(key);progress('height_interior',case)
        del dd,hh,costs;gc.collect()
    progress('height_interior_complete')

def main():
    global ROOT,BASE
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage',choices=['joint','height','all'],default='all')
    parser.add_argument('--sample',nargs='+')
    parser.add_argument('--output',type=Path,default=ROOT)
    parser.add_argument('--nominal',type=Path,default=BASE)
    args=parser.parse_args()
    ROOT=args.output.resolve();BASE=args.nominal.resolve()
    if ROOT.is_relative_to((PACKAGE/'results').resolve()):
        raise ValueError('Choose a fresh output directory outside results/; reference records are preserved.')
    for folder in ['results','analysis','config']:(ROOT/folder).mkdir(parents=True,exist_ok=True)
    pairs=json.loads((CONFIG/'od_pairs.json').read_text(encoding='utf-8'))
    points=json.loads((CONFIG/'points.json').read_text(encoding='utf-8'))
    samples=json.loads((CONFIG/'joint_parameters.json').read_text(encoding='utf-8'))
    assert len(pairs)==6 and len(samples)==40
    freeze_plan(pairs,samples)
    started=time.perf_counter();write_json(ROOT/'analysis'/'environment.json',environment())
    tests=run_tests();regional=tests_new_geometry()
    write_json(ROOT/'analysis'/'algorithm_checks.json',dict(archived=tests,regional=regional))
    print('Algorithm checks passed:',len(tests),'plus',len(regional),'regional tests',flush=True)
    d=load_inputs(PACKAGE);nominal,nomhard=planner.fields(d);nomcost=planner.fused(nominal,W)
    warm_planning_signatures()
    print('Nominal fields ready',flush=True)
    if args.stage in ['joint','all']:run_joint(d,nominal,nomcost,nomhard,pairs,samples,args.sample)
    if args.stage in ['height','all']:
        if args.stage=='all':assert len(read_rows('joint_paired'))==480,'Complete paired tests before proceeding'
        run_height(d,nominal,nomcost,nomhard,pairs,points)
    write_json(ROOT/'analysis'/f'runtime_{args.stage}.json',dict(elapsed_s=time.perf_counter()-started,stage=args.stage,selected_samples=args.sample,finished_utc=datetime.now(timezone.utc).isoformat()))
    print('COMPLETE',args.stage,flush=True)

if __name__=='__main__':main()
