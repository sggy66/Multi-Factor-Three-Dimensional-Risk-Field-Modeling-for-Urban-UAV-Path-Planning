"""Summarize paired parameter comparisons and interior height-error outcomes."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,csv,hashlib,json,shutil
import numpy as np

PACKAGE=Path(__file__).resolve().parents[1]
ROOT=PACKAGE/'results'/'followup'
A=PACKAGE/'runs'/'followup_tables'
def read(name):return [json.loads(s) for s in (ROOT/'results'/(name+'.jsonl')).read_text(encoding='utf-8').splitlines()]
def write_csv(path,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def write_json(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def stats(v):
    v=np.array(v,float)
    return dict(minimum=float(np.min(v)),p10=float(np.quantile(v,.1)),median=float(np.median(v)),p90=float(np.quantile(v,.9)),maximum=float(np.max(v)),mean=float(np.mean(v))) if len(v) else {k:None for k in ['minimum','p10','median','p90','maximum','mean']}
def gain(a,b):return 100*(b-a)/b if abs(b)>1e-12 else None
def compare(a,b):
    tol=max(1e-4,1e-6*max(abs(a),abs(b)))
    return 'full_lower' if a<b-tol else ('simple_lower' if a>b+tol else 'tie')
def fmt(x,n=2):return '—' if x is None else f'{x:.{n}f}'

def main():
    global ROOT,A
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT)
    parser.add_argument('--output',type=Path,default=A)
    args=parser.parse_args();ROOT=args.input.resolve();A=args.output.resolve()
    if A.is_relative_to((PACKAGE/'results').resolve()):raise ValueError('Write summaries outside archived results/')
    A.mkdir(parents=True,exist_ok=True)
    joint=read('joint_paired');height=read('height_interior');fixed=read('fixed_path_interior')
    assert len(joint)==480 and len(height)==len(fixed)==96
    lookup={(r['case_id'],r['od'],r['model']):r for r in joint}
    pairs=json.loads((PACKAGE/'config'/'od_pairs.json').read_text(encoding='utf-8'))
    samples=json.loads((PACKAGE/'config'/'joint_parameters.json').read_text(encoding='utf-8'))
    factor_keys=['pop','alt','road','bld','wth','riv']
    pairrows=[]
    for p in pairs:
        for sample in samples:
            f=lookup[sample['id'],p['id'],'full'];b=lookup[sample['id'],p['id'],'population_alt']
            row=dict(od=p['id'],pair=p['label'],sample_id=sample['id'],rho=sample['rho'],reference_agl_m=sample['params']['hopt'],
                     population_weight=sample['weights'][0],altitude_weight=sample['weights'][1],full_found=f['found'],simple_found=b['found'])
            if f['found'] and b['found']:
                row['ranking']=compare(f['nominal_integral'],b['nominal_integral'])
                for key in ['nominal_integral','nominal_mean','length_m','population_native_mean']+[k+'_nominal_weighted_integral' for k in factor_keys]:
                    row['full_'+key]=f[key];row['simple_'+key]=b[key]
                    row[key+'_benefit_pct']=gain(f[key],b[key])
                    row[key+'_absolute_difference_full_minus_simple']=f[key]-b[key]
            else:row['ranking']='both_failed' if not f['found'] and not b['found'] else ('full_failed' if not f['found'] else 'simple_failed')
            pairrows.append(row)
    assert len(pairrows)==240
    write_csv(A/'joint_paired_differences.csv',pairrows)
    summaries=[];factors=[];metrics=[]
    for p in pairs:
        group=[r for r in pairrows if r['od']==p['id']]
        valid=[r for r in group if r['full_found'] and r['simple_found']]
        counts={k:sum(r['ranking']==k for r in group) for k in ['full_lower','simple_lower','tie','full_failed','simple_failed','both_failed']}
        summary=dict(od=p['id'],pair=p['label'],settings=40,valid_pairs=len(valid),**counts,**stats([r['nominal_integral_benefit_pct'] for r in valid]))
        summaries.append(summary)
        for key in ['nominal_mean','length_m','population_native_mean']+[k+'_nominal_weighted_integral' for k in factor_keys]:
            variable=dict(od=p['id'],pair=p['label'],metric=key,valid_pairs=len(valid),
                          full_lower=sum(compare(r['full_'+key],r['simple_'+key])=='full_lower' for r in valid),
                          simple_lower=sum(compare(r['full_'+key],r['simple_'+key])=='simple_lower' for r in valid),
                          tie=sum(compare(r['full_'+key],r['simple_'+key])=='tie' for r in valid),
                          **stats([r[key+'_benefit_pct'] for r in valid if r[key+'_benefit_pct'] is not None]))
            metrics.append(variable)
            if key.endswith('_nominal_weighted_integral'):factors.append(variable)
    write_csv(A/'Table_S3_paired_summary.csv',summaries)
    write_csv(A/'joint_secondary_metrics_summary.csv',metrics)
    write_csv(A/'joint_factor_outcomes_summary.csv',factors)
    write_csv(A/'joint_all_cases.csv',joint)

    fixed_lookup={(r['case_id'],r['od'],r['model']):r for r in fixed}
    meta={(r['case_id'],r['od'],r['model']):r for r in read('height_case_metadata')}
    combined=[]
    for row in height:
        key=row['case_id'],row['od'],row['model'];f=fixed_lookup[key];m=meta[key]
        merged={**row,'factor':m['factor'],'bias_m':m['bias_m']}
        for k,val in f.items():
            if k not in ['case_id','od','model','factor','bias_m']:merged['fixed_'+k]=val
        combined.append(merged)
    write_csv(A/'height_case_details.csv',combined)
    hs=[]
    for factor in ['terrain','building']:
        for bias in [-10.,-5.,5.,10.]:
            for model in ['full','population_alt']:
                group=[r for r in combined if r['factor']==factor and r['bias_m']==bias and r['model']==model]
                assert len(group)==6
                successful=[r for r in group if r['found']]
                interior=[r['interior_min_clearance_m'] for r in successful if r['interior_min_clearance_m'] is not None]
                fixed_min=[r['fixed_interior_min_clearance_m'] for r in group if r['fixed_interior_min_clearance_m'] is not None]
                hs.append(dict(factor=factor,bias_m=bias,model=model,cases=6,
                               fixed_feasible=sum(r['fixed_feasible'] for r in group),
                               fixed_raw_feasible=sum(r['fixed_raw_feasible'] for r in group),
                               replanning_found=len(successful),endpoint_blocked=sum(r['start_blocked'] or r['goal_blocked'] for r in group),
                               replanned_planning_constraint_violations=sum(r['planning_hard_hits']!=0 for r in successful),
                               replanned_nominal_constraint_violations=sum(r['nominal_hard_hits']!=0 for r in successful),
                               fixed_interior_clearance_min_m=min(fixed_min) if fixed_min else None,
                               fixed_interior_clearance_max_m=max(fixed_min) if fixed_min else None,
                               replanned_interior_clearance_min_m=min(interior) if interior else None,
                               replanned_interior_clearance_max_m=max(interior) if interior else None,
                               replanned_whole_route_clearance_min_m=min((r['min_clearance_m'] for r in successful),default=None)))
    write_csv(A/'Table_S5_interior_summary.csv',hs)
    write_csv(A/'height_all_replanning_cases.csv',height)
    write_csv(A/'height_all_fixed_path_cases.csv',fixed)

    print('Wrote paired and height-error tables to',A,flush=True)

if __name__=='__main__':main()
