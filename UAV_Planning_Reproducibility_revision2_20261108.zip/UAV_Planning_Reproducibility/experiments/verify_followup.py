"""Re-read exported paths and independently reconstruct fields, objectives and clearances."""
from pathlib import Path
import argparse,gc,json,sys,time
import numpy as np

PACKAGE=Path(__file__).resolve().parents[1]
ROOT=PACKAGE/'results'/'followup'
REPORT_DIR=PACKAGE/'runs'/'followup_verification'
sys.path.insert(0,str(PACKAGE/'src'))
import planner
from kernel import path_metrics,run_tests
from surface import surface_stats
from run import load_inputs
from run_followup import tests_new_geometry,localized_data,spatial_profile,height_scenarios,sha,write_json,ROOT,PACKAGE,BASE,W,FACTOR_KEYS,MODELS,path_file,coordinates

ERRORS={}
def check(name,value,saved,absolute=1e-4,relative=3e-6):
    if value is None or saved is None:
        assert value is saved,(name,value,saved)
        return
    error=abs(float(value)-float(saved));ERRORS[name]=max(ERRORS.get(name,0),error)
    assert error<=max(absolute,relative*abs(float(saved))),(name,value,saved,error)

def read_rows(name):return [json.loads(s) for s in (ROOT/'results'/(name+'.jsonl')).read_text(encoding='utf-8').splitlines()]

def audit_path(p,row,d,nominal,nomcost,nomhard,owncost,ownhard,pair,surface_data=None,region=None):
    assert p.ndim==2 and p.shape[1]==3 and len(p)>1 and np.isfinite(p).all()
    assert np.array_equal(p[[0,-1]],np.array([pair['start'],pair['goal']]))
    own=path_metrics(p,owncost[None],ownhard)
    assert own[-1]==0
    common=path_metrics(p,nomcost[None],nomhard)
    factors=path_metrics(p,nominal,nomhard)
    pop=np.broadcast_to(d['pop'][None,:,:,None],(1,*nomhard.shape))
    population=path_metrics(p,pop,nomhard)[2][0]
    for key,value in [('length_m',common[0]),('movement',own[1]),('nominal_integral',common[2][0]),
                      ('nominal_mean',common[2][0]/common[0]),('nominal_peak',common[3][0]),
                      ('own_integral',own[2][0]),('population_native_integral',population),
                      ('population_native_mean',population/common[0]),('nominal_hard_hits',common[-1]),('planning_hard_hits',own[-1])]:
        check(key,value,row[key],0 if key.endswith('hits') else 1e-4,0 if key.endswith('hits') else 3e-6)
    objective=own[1]+row['rho']*own[2][0]
    check('objective',objective,row['objective']);check('objective_independent',objective,row['objective_independent'])
    for k,key in enumerate(FACTOR_KEYS):check(key+'_contribution',W[k]*factors[2][k],row[key+'_nominal_weighted_integral'])
    check('factor_total',np.dot(W,factors[2]),row['nominal_integral'],1e-4,2e-6)
    sd=d if surface_data is None else surface_data
    sf=sd['dem']+sd['bheight']
    clear,ground,agl,maxagl=surface_stats(p,sd['dem'],sf)
    for key,value in [('min_clearance_m',clear),('min_terrain_clearance_m',ground),('mean_agl_m',agl),('max_agl_m',maxagl)]:check(key,value,row[key])
    if region is not None:
        # Reference check uses the unchanged complete-surface routine with non-region
        # cells lowered out of contention, rather than the new regional routine.
        masked=np.where(region,sf,-1e9).astype('f4')
        interior=surface_stats(p,sd['dem'],masked)[0]
        check('interior_min_clearance_m',None if interior>1e8 else interior,row['interior_min_clearance_m'])
        indicator=np.broadcast_to(region.astype('f4')[None,:,:,None],(1,*nomhard.shape))
        length=path_metrics(p,indicator,ownhard)[2][0]
        check('interior_path_length_m',length,row['interior_path_length_m'])

def verify_joint(d,nominal,nomcost,nomhard,pairs,samples):
    ERRORS.clear()
    rows=read_rows('joint_paired');lookup={(r['case_id'],r['od'],r['model']):r for r in rows}
    assert len(lookup)==len(rows)
    checked=0;legacy=0;failed=[]
    for sample in samples:
        ff,hh=planner.fields(d,sample['params']);assert np.array_equal(hh,nomhard)
        weights=np.array(sample['weights']);simple=weights.copy();simple[2:]=0
        costs={'full':planner.fused(ff,weights),'population_alt':planner.fused(ff,simple)}
        del ff;gc.collect()
        for pair in pairs:
            for model in MODELS:
                row=lookup[sample['id'],pair['id'],model]
                assert row['rho']==sample['rho']
                assert np.array_equal(row['weights'],weights if model=='full' else simple)
                filename=path_file('joint_paired',sample['id'],pair['id'],model)
                if not row['found']:
                    assert not filename.exists();failed.append((sample['id'],pair['id'],model));continue
                with np.load(filename,allow_pickle=False) as a:p=a['index'];xyz=a['xyz']
                assert np.array_equal(xyz,coordinates(d,p))
                audit_path(p,row,d,nominal,nomcost,nomhard,costs[model],hh,pair)
                assert row['nominal_hard_hits']==0 and not row['reconstruction']
                if model=='full' and pair['id'] in ['OD01','OD02']:
                    source=PACKAGE/'results'/'reference'/'paths'/'joint'/f'{pair["id"]}_{sample["id"]}.npz'
                    with np.load(source,allow_pickle=False) as old:assert np.array_equal(old['index'],p)
                    legacy+=1
                checked+=1
        print('verified joint',sample['id'],'paths',checked,flush=True)
        del costs,hh;gc.collect()
    report=dict(stage='joint_paired',expected_cases=len(samples)*len(pairs)*len(MODELS),exported_paths_checked=checked,failed_cases=failed,
                archived_full_model_paths_exact=legacy,all_shared_weights_and_parameters_matched=True,maximum_absolute_differences=ERRORS.copy())
    write_json(REPORT_DIR/'verification_joint.json',report)

def verify_height(d,nominal,nomcost,nomhard,pairs,points,selected_cases=None):
    ERRORS.clear()
    rows=read_rows('height_interior');fixed=read_rows('fixed_path_interior')
    lookup={(r['case_id'],r['od'],r['model']):r for r in rows};fix={(r['case_id'],r['od'],r['model']):r for r in fixed}
    assert len(lookup)==len(rows)==len(fix)==len(fixed)
    distance,multiplier,region=spatial_profile(d,points)
    profile=ROOT/'config'/'height_spatial_profile.npz'
    if profile.exists():
        with np.load(profile) as a:
            assert np.array_equal(a['distance_m'],distance) and np.array_equal(a['multiplier'],multiplier) and np.array_equal(a['full_amplitude_region'],region)
    checked=0;fixed_checked=0;failed=[]
    for factor,bias,case in height_scenarios():
        if selected_cases and case not in selected_cases:continue
        dd=localized_data(d,factor,bias,multiplier)
        ff,hh=planner.fields(dd)
        for point in points.values():assert hh[tuple(point)]==nomhard[tuple(point)]==False
        costs={'full':planner.fused(ff,W),'population_alt':planner.fused(ff,np.array([.35,.15,0,0,0,0]))}
        del ff;gc.collect()
        sf=dd['dem']+dd['bheight'];masked=np.where(region,sf,-1e9).astype('f4')
        for pair in pairs:
            assert lookup[case,pair['id'],'full']['found']==lookup[case,pair['id'],'population_alt']['found'],'Shared feasible graph has inconsistent search outcomes'
            for model in MODELS:
                f=fix[case,pair['id'],model]
                with np.load(BASE/'paths'/'core'/f'{pair["id"]}_{model}.npz') as a:p=a['index'];raw=a['raw_index'].astype(float)
                hits=path_metrics(p,np.empty((0,*hh.shape),'f4'),hh)[-1]
                rawhits=path_metrics(raw,np.empty((0,*hh.shape),'f4'),hh)[-1]
                assert hits==f['hard_hits'] and rawhits==f['raw_hard_hits'] and f['feasible']==(hits==0)
                assert not f['start_blocked'] and not f['goal_blocked']
                check('fixed_min_clearance_m',surface_stats(p,dd['dem'],sf)[0],f['min_clearance_m'])
                interior=surface_stats(p,dd['dem'],masked)[0]
                check('fixed_interior_min_clearance_m',None if interior>1e8 else interior,f['interior_min_clearance_m'])
                indicator=np.broadcast_to(region.astype('f4')[None,:,:,None],(1,*hh.shape))
                check('fixed_interior_length_m',path_metrics(p,indicator,hh)[2][0],f['interior_path_length_m'])
                fixed_checked+=1
                row=lookup[case,pair['id'],model]
                assert row['rho']==12 and np.array_equal(row['weights'],W if model=='full' else np.array([.35,.15,0,0,0,0]))
                assert not row['start_blocked'] and not row['goal_blocked']
                filename=path_file('height_interior',case,pair['id'],model)
                if not row['found']:
                    assert not filename.exists();failed.append((case,pair['id'],model,row['failure_reason']));continue
                with np.load(filename) as a:p=a['index'];xyz=a['xyz']
                assert np.array_equal(xyz,coordinates(d,p))
                audit_path(p,row,d,nominal,nomcost,nomhard,costs[model],hh,pair,dd,region)
                checked+=1
        print('verified height',case,'fixed',fixed_checked,'replanned',checked,flush=True)
        del costs,hh,dd;gc.collect()
    report=dict(stage='height_interior',expected_replanning_cases=len([c for _,_,c in height_scenarios() if not selected_cases or c in selected_cases])*len(pairs)*len(MODELS),exported_paths_checked=checked,fixed_paths_checked=fixed_checked,
                failed_cases=failed,all_endpoint_states_unchanged_and_feasible=True,
                regional_clearance_check='independent masked-surface computation using original surface_stats',maximum_absolute_differences=ERRORS.copy())
    write_json(REPORT_DIR/'verification_height.json',report)

def main():
    global ROOT,BASE,REPORT_DIR
    import run_followup as driver
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage',choices=['joint','height','all'],default='all')
    parser.add_argument('--input',type=Path,default=PACKAGE/'results'/'followup')
    parser.add_argument('--nominal',type=Path,default=PACKAGE/'results'/'six_od')
    parser.add_argument('--report-dir',type=Path,default=REPORT_DIR)
    parser.add_argument('--sample',nargs='+',help='verify selected saved joint settings')
    parser.add_argument('--case',nargs='+',help='verify selected height cases, e.g. building_p10')
    args=parser.parse_args()
    ROOT=args.input.resolve();BASE=args.nominal.resolve();REPORT_DIR=args.report_dir.resolve()
    if REPORT_DIR.is_relative_to((PACKAGE/'results').resolve()):
        raise ValueError('Verification reports must be written outside the archived results directory.')
    driver.ROOT=ROOT;driver.BASE=BASE
    started=time.perf_counter()
    plan=json.loads((PACKAGE/'config'/'followup_sources.json').read_text(encoding='utf-8'))
    for relative,digest in plan['sources'].items():assert sha(PACKAGE/relative)==digest,'Source changed: '+relative
    tests=run_tests();regional=tests_new_geometry()
    write_json(REPORT_DIR/'algorithm_checks.json',dict(archived=tests,regional=regional))
    pairs=json.loads((PACKAGE/'config'/'od_pairs.json').read_text(encoding='utf-8'))
    points=json.loads((PACKAGE/'config'/'points.json').read_text(encoding='utf-8'))
    samples=json.loads((PACKAGE/'config'/'joint_parameters.json').read_text(encoding='utf-8'))
    if args.sample:
        assert set(args.sample)<=set(s['id'] for s in samples),'Unknown sample'
        samples=[s for s in samples if s['id'] in args.sample]
    if args.case:assert set(args.case)<=set(c for _,_,c in height_scenarios()),'Unknown height case'
    d=load_inputs(PACKAGE);nominal,nomhard=planner.fields(d);nomcost=planner.fused(nominal,W)
    if args.stage in ['joint','all']:verify_joint(d,nominal,nomcost,nomhard,pairs,samples)
    if args.stage in ['height','all']:verify_height(d,nominal,nomcost,nomhard,pairs,points,args.case)
    write_json(REPORT_DIR/'verification_runtime.json',dict(elapsed_s=time.perf_counter()-started,stage=args.stage,selected_samples=args.sample,selected_height_cases=args.case))
    print('VERIFIED',args.stage,flush=True)

if __name__=='__main__':main()
