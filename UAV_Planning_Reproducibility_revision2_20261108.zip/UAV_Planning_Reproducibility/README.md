# Multi-Factor Three-Dimensional Risk Field Modeling for Urban UAV Path Planning

Code, processed inputs and reference results for six origin–destination pairs in Hangzhou, China. Detailed baseline and factor analyses use the original two pairs. The six fields express dimensionless planning costs and exposure proxies. Their weighted sum is not an accident or casualty probability.

## Contents

- `data/planning_inputs.npz`: processed 5 m planning inputs, including terrain, population, precipitation, geometric distances and masks.
- `config/`: six endpoint pairs, their four shared points, nominal parameters and 40 frozen joint settings; the original two-pair configuration is retained separately.
- `src/`: field construction, constrained A* search, trajectory reconstruction and evaluation.
- `scripts/`: result-table summaries.
- `results/reference/`: recorded results and paths for the two pairs.
- `results/tables/`: compact tables derived from the reference CSV files.
- `docs/`: methods, pseudocode, data definitions and performance measurement.

The included inputs are sufficient to rebuild the planning fields and run the experiments. This workflow starts from processed inputs; it does not redownload or reproduce the original nationwide GIS products. Input preparation and source information are described in [Data](docs/DATA.md).

## Installation

Use Python 3.10 and a 64-bit environment. The reference machine had approximately 16 GB of RAM. Large 5 m experiments hold several three-dimensional arrays in memory.

```bash
python -m venv .venv
```

Activate the environment using the command appropriate for your operating system, then install the recorded scientific dependencies:

```bash
python -m pip install -r requirements.txt
```

## Running

Run commands from the repository root. Outputs are written to `runs/` by default, keeping reference results intact.

```bash
python scripts/verify_package.py
python src/run.py --stage verify
python src/run.py --stage benchmark --od OD01 --output runs/pair1
python src/run.py --stage benchmark --od OD02 --output runs/pair2
python src/run.py --stage verify --output results/reference --table core
python src/run.py --stage core
python src/run.py --stage robust
python src/run.py --stage performance
python scripts/summarize_results.py --input results/reference --output runs/tables
```

`verify` runs the small-graph algorithm checks and, when the selected output directory contains case records, independently checks the exported paths. `--table core` selects the recorded core paths without rerunning planning. Verification reports are written to `runs/verification.json` (or `--report`) and do not overwrite the reference records.

The core stage covers the full model, uniform cost, population-only coefficients 1 and 0.35, population plus altitude, fixed-weight and renormalized deletions, individual and cumulative factor additions, and the 60 m AGL control. The robust stage uses the same two endpoint pairs for risk–distance scans, 40 joint settings, terrain/building offsets and the monthly-precipitation threshold scenario. The performance stage evaluates 5, 10 and 20 m grids and 800, 1200 and 1600 m corridor margins.

Two pairs × 40 joint settings means 80 parameter runs, not 80 different endpoint pairs. The frozen settings in `config/joint_parameters.json` are the reproducible parameter specification; use this file directly rather than regenerate it from the seed.


## Six-pair comparison and matched sensitivity experiments

The four original endpoints form six fixed pairs. Computational IDs OD01–OD06
map to the paper's Pairs 1–6; A=S1, B=G1, C=S2 and D=G2. The complete mapping
is in `config/endpoint_labels.json`. Original computational identifiers remain
in archived records. OD03 and OD04 are on the same bank of the main river;
tributary crossings remain possible. All pairs use the same NFZ geometry.

`src/run.py` defaults to OD01 and OD02 for the original detailed experiments.
For the extended nominal comparison, explicitly select all six pairs and the
two models:

```bash
python src/run.py --stage core --od OD01 OD02 OD03 OD04 OD05 OD06 --variant full population_alt --output runs/six_od
python src/run.py --stage verify --output results/six_od --table core --report runs/verify_six_od.json
python scripts/summarize_six_od.py --output runs/six_od_tables
```

The summary command uses archived nominal results by default. To summarize a
fresh nominal run, add `--input runs/six_od`; to verify it, replace
`--output results/six_od` with `--output runs/six_od` in the verification command.

Run the new matched tests, verify saved paths, and recreate their tables:

```bash
python experiments/run_followup.py --stage all --output runs/followup
python experiments/verify_followup.py --input results/followup --report-dir runs/verify_followup
python experiments/summarize_followup.py --output runs/followup_tables
```

The height tests use the archived nominal paths by default. To use freshly
replanned nominal paths, add `--nominal runs/six_od` to the run and verification
commands. To verify freshly generated follow-up results, use
`--input runs/followup`. A short verification of archived data is available:

```bash
python experiments/verify_followup.py --stage joint --sample J00 --report-dir runs/verify_joint_J00
python experiments/verify_followup.py --stage height --case building_p10 --report-dir runs/verify_height_p10
```

Reference records:

- `results/reference/` and `results/tables/`: original detailed two-pair results.
- `results/six_od/`: 12 nominal trajectories and their common-field metrics.
- `results/followup/results/`: 480 parameter runs, 96 interior-error replans and
  96 fixed-path checks, including per-case records and path arrays.
- `results/followup/tables/`: paired differences, distribution summaries and
  factor-specific/clearance results used for Tables S3 and S5(b).

The original six blocked-endpoint failures remain in
`results/reference/height_error.csv`. The original 80 single-model joint runs
are retained for traceability; the paired 480-run extension supplies the updated
comparison. See [Extended experiments](docs/EXTENDED_EXPERIMENTS.md).

## Reference results

The original measured timings depend on the reference machine, library versions, compilation state and memory already resident in the process. Repeated runs on another machine need not have identical wall-clock times. Scientific metrics should agree within floating-point tolerance.

- [Methods and pseudocode](docs/METHODS.md)
- [Input data and processing](docs/DATA.md)
- [Performance measurements](docs/PERFORMANCE.md)
- [Result fields](docs/RESULTS.md)
- [Verification](docs/VERIFICATION.md)
- [Release validation](docs/PACKAGE_VALIDATION.md)

SHA-256 checksums in `checksums.sha256` identify the distributed files. There are no manuscript files, review correspondence, literature PDFs or full-country raw datasets in this repository.
