"""Check the distributed file inventory and SHA-256 checksums."""
from pathlib import Path
import hashlib
import sys


def main():
    root = Path(__file__).resolve().parents[1]
    inventory = root / 'checksums.sha256'
    checked = 0
    for line in inventory.read_text(encoding='utf-8').splitlines():
        expected, relative = line.split('  ', 1)
        target = (root / relative).resolve()
        if not target.is_relative_to(root):
            raise ValueError('Checksum entry is outside the repository: ' + relative)
        digest = hashlib.sha256()
        with target.open('rb') as stream:
            for block in iter(lambda: stream.read(2**20), b''):
                digest.update(block)
        if digest.hexdigest() != expected:
            raise ValueError('Checksum mismatch: ' + relative)
        checked += 1
    print('Verified', checked, 'distributed files')


if __name__ == '__main__':
    main()
