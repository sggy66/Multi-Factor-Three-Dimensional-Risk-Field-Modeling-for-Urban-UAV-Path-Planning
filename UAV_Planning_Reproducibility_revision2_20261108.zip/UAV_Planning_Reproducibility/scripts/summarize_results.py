"""Summarize recorded case metrics without changing their evaluation field."""
from pathlib import Path
import argparse
import csv
import statistics
import json
import numpy as np


def load(folder, name):
    with (folder / (name + '.csv')).open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def save(folder, name, columns, rows):
    with (folder / (name + '.csv')).open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=Path('results/reference'))
    parser.add_argument('--output', type=Path, default=Path('runs/tables'))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    rows = [r for r in load(args.input, 'core') if r['od'] in {'OD01', 'OD02'}]
    keys = ['od', 'variant', 'found', 'length_m', 'mean_risk', 'risk_integral',
            'population_native_mean', 'avg_agl_m', 'min_segment_nominal_surface_clearance_m']
    controls = {'full', 'uniform', 'population_1', 'population_035',
                'population_alt', 'constant_agl60'}
    for name, selected in [
        ('core_controls', [r for r in rows if r['variant'] in controls]),
        ('ablations', [r for r in rows if r['variant'] in {'full', 'uniform'}
                       or r['variant'].startswith(('fixed_remove_', 'renorm_remove_'))]),
        ('factor_additions', [r for r in rows if r['variant'] in {'full', 'population_alt'}
                             or r['variant'].startswith(('add_', 'progressive_through_'))]),
    ]:
        save(args.output, name, keys, [{k: r.get(k, '') for k in keys} for r in selected])
    keys = ['od', 'variant', 'raw_length_m', 'length_m', 'raw_risk_integral', 'risk_integral',
            'raw_peak_risk', 'peak_risk', 'raw_min_segment_nominal_surface_clearance_m',
            'min_segment_nominal_surface_clearance_m', 'raw_roughness_rms_m',
            'smooth_roughness_rms_m', 'hard_intersections', 'smooth_status']
    save(args.output, 'reconstruction', keys,
         [{k: r.get(k, '') for k in keys} for r in rows
          if r['variant'] in controls and r['variant'] != 'constant_agl60'])
    joint = load(args.input, 'joint')
    summary = []
    for od in ['OD01', 'OD02']:
        selected = [r for r in joint if r['od'] == od]
        found = [r for r in selected if r['found'].lower() == 'true']
        values = [float(r['mean_risk']) for r in found]
        summary.append(dict(od=od, runs=len(selected), successes=len(found),
                            minimum_mean_cost=min(values) if values else '',
                            median_mean_cost=statistics.median(values) if values else '',
                            maximum_mean_cost=max(values) if values else ''))
    save(args.output, 'joint_summary', list(summary[0]), summary)
    ratio = load(args.input, 'ratio')
    lookup = {(r['od'], r['variant']): r for r in ratio}
    labels = [('full', 'Full model'), ('population_1', 'Population only (1)'),
              ('population_035', 'Population only (0.35)')]
    scan_rows = []
    for coefficient in [3, 6, 12, 24, 48]:
        for model, label in labels:
            item = dict(coefficient=coefficient, model=label)
            for number, od in enumerate(['OD01', 'OD02'], 1):
                row = lookup[(od, model + '_rho' + str(coefficient))]
                base = lookup[(od, 'full_rho' + str(coefficient))]
                if row['found'].lower() != 'true' or float(base['population_native_mean']) <= 0:
                    raise ValueError('Scan summary requires a valid path and positive matching population baseline')
                item[f'pair{number}_mean_cost'] = float(row['mean_risk'])
                item[f'pair{number}_relative_mean_population'] = (
                    float(row['population_native_mean']) / float(base['population_native_mean']))
            scan_rows.append(item)
    save(args.output, 'ratio_summary', list(scan_rows[0]), scan_rows)
    errors = {(r['od'], r['variant']): r for r in load(args.input, 'height_error')}
    fixed = {(r['od'], r['variant']): r for r in load(args.input, 'fixed_path_error')}
    repository = Path(__file__).resolve().parents[1]
    pairs = {r['id']: r for r in json.loads((repository / 'config/od_pairs.json').read_text(encoding='utf-8'))}
    with np.load(repository / 'data/planning_inputs.npz', allow_pickle=False) as archive:
        arrays = {k: archive[k] for k in ['dem', 'bheight', 'bmask', 'valid', 'nfz', 'z']}
    height_rows = []
    for factor, prefix in [('Terrain', 'terrain_shift'), ('Building height', 'building_shift')]:
        for shift in [-10, -5, 5, 10]:
            item = dict(factor=factor, bias_m=shift)
            for number, od in enumerate(['OD01', 'OD02'], 1):
                variant = prefix + str(shift)
                original = fixed[(od, variant)]
                replanned = errors[(od, variant)]
                item[f'pair{number}_fixed_path'] = ('Feasible' if original['found'].lower() == 'true' else 'Infeasible')
                if replanned['found'].lower() == 'true':
                    status = 'Found'
                else:
                    blocked = False
                    for endpoint in ['start', 'goal']:
                        x, y, z_index = pairs[od][endpoint]
                        z = float(arrays['z'][z_index])
                        terrain = float(arrays['dem'][x, y]) + (shift if prefix == 'terrain_shift' else 0)
                        height = max(float(arrays['bheight'][x, y]) + (shift if prefix == 'building_shift' else 0), 0)
                        blocked |= (not arrays['valid'][x, y] or arrays['nfz'][x, y]
                                    or z - 2.5 <= terrain or z + 2.5 > terrain + 120
                                    or (arrays['bmask'][x, y] and z - 2.5 <= terrain + height))
                    status = 'Blocked endpoint' if blocked else 'No path'
                item[f'pair{number}_replanning'] = status
            height_rows.append(item)
    save(args.output, 'height_bias_feasibility', list(height_rows[0]), height_rows)
    configurations = list(dict.fromkeys(r['variant'] for r in rows if r['variant'] != 'constant_agl60'))
    core_lookup = {(r['od'], r['variant']): r for r in rows}
    factor_names = dict(pop='Population', alt='Altitude', road='Road', bld='Building',
                        wth='Precipitation', riv='Water')
    additions = dict(road='P+A+Road', bld='P+A+Building', wth='P+A+Precipitation', riv='P+A+Water')
    base_labels = dict(full='Full model', uniform='Uniform', population_1='Population only (1)',
                       population_035='Population only (0.35)', population_alt='P+A',
                       progressive_through_bld='P+A+Road+Building',
                       progressive_through_wth='P+A+Road+Building+Precipitation')
    objective_rows = []
    for variant in configurations:
        if variant.startswith('fixed_remove_'):
            label = 'Fixed -' + factor_names[variant[len('fixed_remove_'):]]
        elif variant.startswith('renorm_remove_'):
            label = 'Renormalized -' + factor_names[variant[len('renorm_remove_'):]]
        elif variant.startswith('add_'):
            label = additions[variant[len('add_'):]]
        else:
            label = base_labels[variant]
        item = {'Configuration': label}
        for number, od in enumerate(['OD01', 'OD02'], 1):
            row = core_lookup[(od, variant)]
            objective = float(row['objective_discrete'])
            movement = float(row['movement_discrete'])
            soft = float(row['risk_term_discrete'])
            if abs(objective-movement-soft) > 1e-6:
                raise ValueError('Discrete objective decomposition mismatch')
            item[f'Pair {number} movement (m)'] = f'{movement:.1f}'
            item[f'Pair {number} soft term (m)'] = f'{soft:.1f}'
            item[f'Pair {number} own objective (m)'] = f'{objective:.1f}'
        objective_rows.append(item)
    save(args.output, 'discrete_objectives', list(objective_rows[0]), objective_rows)
    cross_columns = ['Pair', 'Path', 'Full-field objective (m)',
                     'Population (1) objective (m)', 'Population (0.35) objective (m)']
    cross_labels = [('full', 'Full model'), ('population_1', 'Population only (1)'),
                    ('population_035', 'Population only (0.35)')]
    cross_fields = ['raw_objective_nominal_full', 'raw_objective_population1',
                    'raw_objective_population035']
    cross_rows = []
    for number, od in enumerate(['OD01', 'OD02'], 1):
        for variant, label in cross_labels:
            row = core_lookup[(od, variant)]
            if row['found'].lower() != 'true':
                raise ValueError('Cross-objective summary requires a valid path')
            item = {'Pair': 'Pair ' + str(number), 'Path': label}
            for column, field in zip(cross_columns[2:], cross_fields):
                item[column] = f'{float(row[field]):.1f}'
            cross_rows.append(item)
    save(args.output, 'cross_objectives', cross_columns, cross_rows)
    nominal_weights = json.loads((repository / 'config/experiment.json').read_text(encoding='utf-8'))['weights']
    factor_fields = ['pop_integral', 'alt_integral', 'road_integral', 'bld_integral', 'wth_integral', 'riv_integral']
    contribution_columns = ['Pair', 'Configuration', 'Population (m)', 'Altitude (m)',
                            'Road (m)', 'Building (m)', 'Precipitation (m)', 'Water (m)']
    configuration_labels = {v: item['Configuration'] for v, item in zip(configurations, objective_rows)}
    configuration_labels['constant_agl60'] = '60 m AGL cruise'
    contribution_rows, contribution_summary = [], []
    for row in rows:
        values = [w * float(row[field]) for w, field in zip(nominal_weights, factor_fields)]
        if row['found'].lower() != 'true' or abs(sum(values) - float(row['risk_integral'])) > 0.001:
            raise ValueError('Nominal weighted factor contributions do not reconstruct the full-field integral')
        item = dict(zip(contribution_columns, ['Pair ' + str(int(row['od'][-2:])),
                                             configuration_labels[row['variant']]] + values))
        item['Nominal full-field integral (m)'] = float(row['risk_integral'])
        contribution_rows.append(item)
        if row['variant'] in controls or row['variant'].startswith(('add_', 'progressive_through_')):
            contribution_summary.append({k: f'{v:.1f}' if isinstance(v, float) else v
                                         for k, v in item.items() if k in contribution_columns})
    save(args.output, 'factor_contributions', contribution_columns + ['Nominal full-field integral (m)'], contribution_rows)
    save(args.output, 'factor_contributions_summary', contribution_columns, contribution_summary)
    print('Wrote summaries to', args.output)


if __name__ == '__main__':
    main()
