"""Export six-pair nominal comparison tables from recorded case metrics."""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
from scipy.ndimage import gaussian_filter

PACKAGE = Path(__file__).resolve().parents[1]


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=PACKAGE / "results/six_od")
    parser.add_argument("--output", type=Path, default=PACKAGE / "runs/six_od_tables")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.is_relative_to((PACKAGE / "results").resolve()):
        raise ValueError("Write summaries outside archived results/")
    output.mkdir(parents=True, exist_ok=True)
    rows = [json.loads(line) for line in (args.input / "core.jsonl").read_text(encoding="utf-8").splitlines()]
    pairs = json.loads((PACKAGE / "config/od_pairs.json").read_text(encoding="utf-8"))
    lookup = {(r["od"], r["variant"]): r for r in rows}
    assert len(lookup) == len(rows) == 12
    assert set(lookup) == {(p["id"], v) for p in pairs for v in ["full", "population_alt"]}
    table9, table10, differences, scenes = [], [], [], []
    with np.load(PACKAGE / "data/planning_inputs.npz", allow_pickle=False) as archive:
        density = gaussian_filter(archive["bmask"].astype(float), 40)
        water_distance, nfz = archive["dwater"], archive["nfz"]
    for pair in pairs:
        od = pair["id"]
        a, b = lookup[od, "full"], lookup[od, "population_alt"]
        for model, row in [("Full", a), ("P+A", b)]:
            ok = row["found"]
            table9.append({"Pair": int(od[2:]), "Model": model,
                "Length (m)": f"{row['length_m']:.1f}" if ok else None,
                "Mean cost": f"{row['mean_risk']:.4f}" if ok else None,
                "Cost integral (m)": f"{row['risk_integral']:.1f}" if ok else None,
                "Mean population proxy": f"{row['population_native_mean']:.2f}" if ok else None})
        valid = a["found"] and b["found"]
        delta = {"Pair": int(od[2:])}
        for title, key in [("Road (%)", "road"), ("Building (%)", "bld"),
                           ("Precipitation (%)", "wth"), ("Water (%)", "riv")]:
            if valid:
                fa, fb = float(a[key + "_integral"]), float(b[key + "_integral"])
                delta[title] = f"{100 * (fa / fb - 1):+.2f}" if fb else None
            else:
                delta[title] = None
        table10.append(delta)
        changes = {"od": od, "full_found": a["found"], "simple_found": b["found"]}
        for key in ["length_m", "risk_integral", "mean_risk", "population_native_mean"]:
            changes[key + "_change_pct"] = 100 * (a[key] / b[key] - 1) if valid and b[key] else None
        differences.append(changes)
        start, goal = np.array(pair["start"]), np.array(pair["goal"])
        ij = np.rint(start[:2, None] + (goal[:2] - start[:2])[:, None] * np.linspace(0, 1, 500)).astype(int)
        ii, jj = ij
        land = water_distance[ii, jj] > 1e-6
        scenes.append({"od": od, "main_river_relation": pair["main_river_relation"],
            "land_only_building_coverage_proxy": float(np.mean(density[ii[land], jj[land]])),
            "straight_connection_intersects_nfz": bool(np.any(nfz[ii, jj])),
            "coverage_sigma_m": 200, "connection_samples": 500})
    write_csv(output / "Table_S9.csv", table9)
    write_csv(output / "Table_S10.csv", table10)
    write_csv(output / "paired_differences.csv", differences)
    write_csv(output / "scene_context.csv", scenes)
    print("Wrote six-pair comparison tables to", output)


if __name__ == "__main__":
    main()
